<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\IncomeOutgoing;

class IncomeOutgoingController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('income_outgoing.income_outgoing');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        $request->validate([
            'question' => 'required',
            'type' => 'required',
            'sub_type' => 'required'
        ]);

        $income_outgoing = new IncomeOutgoing();
        $income_outgoing->question = $request->question;
        $income_outgoing->type = $request->type;
        $income_outgoing->sub_type = $request->sub_type;
        $income_outgoing->save();
        return response()->json($income_outgoing);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        $type = ['Income', 'outgoing'];
        $records = IncomeOutgoing::all();
        return view('income_outgoing.income_outgoing')->with([
            'records' => $records,
            'type' => $type,
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request)

    {
        $data['Income'] = [
            "1" => "User Income Benefits",
            "2" => "User Income Pensions",
            "3" => "User Income Wages",
            "4" => "User Other Income"
        ];
        $data['outgoing'] = [
            "1" => "User Outgoing Questions",
            "2" => "ESSENTIAL EXPENDITURE",
            "3" => "HOUSEKEEPING",
            "4" => "PHONE",
            "5" => "TRAVEL",
            "6" => "OTHER EXP"
        ];

        $type = $request->type;
        $html = "";
        foreach ($data[$type] as $key => $value) {
            $html .= '<option value="' . $key . '">' . $value . '</option>';
        }
        return response()->json($html);
    }


    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {

        $id = $request->id;
        $records = IncomeOutgoing::find($id);
        $type = $records->type;
        $Income = [
            "1" => "User Income Benefits",
            "2" => "User Income Pensions",
            "3" => "User Income Wages",
            "4" => "User Other Income"
        ];
        $outgoing = [
            "1" => "User Outgoing Questions",
            "2" => "ESSENTIAL EXPENDITURE",
            "3" => "HOUSEKEEPING",
            "4" => "PHONE",
            "5" => "TRAVEL",
            "6" => "OTHER EXP"
        ];
        $data = [];
        if ($type == "Income") {
            foreach ($Income as $key => $value) {
                if ($key == $records->sub_type) {
                    $data[] = [$key => $value];
                }
            }
        } else {
            foreach ($outgoing as $key => $value) {
                if ($key == $records->sub_type) {
                    $data[] = [$key => $value];
                }
            }
        }

        $data[] = $records;
        return response()->json($data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        $id = $request->id;
        $request->validate([
            'question' => 'required',
            'type' => 'required',
        ]);
        $incomeOutgoingUpdate = IncomeOutgoing::find($id);
        $incomeOutgoingUpdate->question = $request->question;
        $incomeOutgoingUpdate->type = $request->type;
        $incomeOutgoingUpdate->sub_type = $request->sub_type;
        $incomeOutgoingUpdate->save();
        return response()->json($incomeOutgoingUpdate);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        $id = $request->id;
        $deleteQue = IncomeOutgoing::find($id);
        if ($deleteQue) {
            $deleteQue->delete();
            return response()->json(array('success' => true));
        }
    }
    public function deleteMultipleQuestion(Request $request)
    {
        $ids = $request->ids;
        $deleteMultipleQuestion = IncomeOutgoing::whereIn('id', $ids)->delete();
        if ($deleteMultipleQuestion) {
            echo json_encode('success');
        }
    }
    public function allIncomeOutgoings(Request $request)
    {
        $columns = array(
            0 => 'id',
            1 => 'question',
            2 => 'type',
            3 => 'sub_type'
        );
        $totalData = IncomeOutgoing::count();
        $totalFiltered = $totalData;
        $limit = $request->input('length');
        $start = $request->input('start');
        $order = $columns[$request->input('order.0.column')];
        $dir = $request->input('order.0.dir');

        if (empty($request->input('search.value'))) {
            $posts = IncomeOutgoing::offset($start)
                ->limit($limit)
                ->orderBy($order, $dir)
                ->get();
        } else {
            $search = $request->input('search.value');
            $posts =  IncomeOutgoing::where('id', 'LIKE', "%{$search}%")
                ->orWhere('question', 'LIKE', "%{$search}%")
                ->orWhere('type', 'LIKE', "%{$search}%")
                ->offset($start)
                ->limit($limit)
                ->orderBy($order, $dir)
                ->get();

            $totalFiltered = IncomeOutgoing::where('id', 'LIKE', "%{$search}%")
                ->orWhere('question', 'LIKE', "%{$search}%")
                ->count();
        }

        $data = array();
        $status = "";
        if (!empty($posts)) {
            foreach ($posts as $post) {
                $nestedData['id'] = '<div class="app-radio" class="allData"><input type="checkbox" name="multiple_check"
                class="multiple_check" value="' . $post->id . '" /></div>';
                $nestedData['question'] = $post->question;
                $nestedData['sub_type'] = $post->sub_type;
                $nestedData['type'] = $post->type;
                $nestedData['action'] =
                    '<a href="" data-id="' . $post->id . '" class="edit_question"><button class="btn btn-success"><i
                    class="fa fa-pencil" aria-hidden="true"></i></button></a><a href="" data-id="' . $post->id . '" class="delete_question"><button class="btn btn-danger"><i
                class="fa fa-trash" aria-hidden="true"></i></button></a>';
                $data[] = $nestedData;
            }
        }
        $json_data = array(
            "draw"            => intval($request->input('draw')),
            "recordsTotal"    => intval($totalData),
            "recordsFiltered" => intval($totalFiltered),
            "data"            => $data
        );
        echo json_encode($json_data);
        exit;
    }
}
