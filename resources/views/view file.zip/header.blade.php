<div class="row">
    <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
        <div class="logo float-right">
            <img src="{!! asset('images/Light blue_Freeze logo@2x.png') !!}" alt="Freeze Crm" class="img-fluid" width="180">
        </div>
        <!--@if (Route::currentRouteName() == 'viewUser')-->
        <!--	 <div class="float-right">-->
        <!--		<a class="Motu btn btn-primary" href="{{ route('listUser') }}">Exit Case</a>-->
        <!--	</div>-->
        <!--@endif-->

    </div>
</div>
