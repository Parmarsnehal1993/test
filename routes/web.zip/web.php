<?php

use App\Http\Controllers\CaseStatusController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\DebtController;
use App\Http\Controllers\AssetController;
use App\Http\Controllers\GeneralSettingController;
use App\Http\Controllers\GeneralSettingGroupController;
use App\Http\Controllers\IncomeOutgoingController;
use Illuminate\Support\Facades\Auth;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/welcome', function () {
    return view('welcome');
});
Route::get('/', function () {
    return view('auth.login');
});

Route::get('/time', function () {
    echo date('Y-m-d H:i:s');
});

Auth::routes();

//for case status
Route::get('/case-statuses', [CaseStatusController::class, 'index'])->name('case_status');
Route::post('/add-case', [CaseStatusController::class, 'create'])->name('add_case');
Route::get('/view-case-status', [CaseStatusController::class, 'store'])->name('view_case_status');
Route::post('/all-case-status', [CaseStatusController::class, 'allCaseStatus'])->name('all_case_status');
Route::get('/edit-case/{records}', [CaseStatusController::class, 'edit'])->name('edit_case');
Route::post('/update-case/{id}', [CaseStatusController::class, 'update'])->name('update_case');
Route::post('/delete-case/{id}', [CaseStatusController::class, 'delete'])->name('delete_case');
Route::post('/delete-all', [CaseStatusController::class, 'deleteAll'])->name('delete_all');
Route::post('/active-all', [CaseStatusController::class, 'activeAll'])->name('active_all');
Route::post('/inactive-all', [CaseStatusController::class, 'inactiveAll'])->name('inactive_all');



//for debt type
Route::get('/debts', [DebtController::class, 'index'])->name('debt');
Route::post('/add-debt', [DebtController::class, 'create'])->name('add_debt');
Route::get('/view-debt', [DebtController::class, 'store'])->name('view_debt');
Route::post('/all-debt-type', [DebtController::class, 'allDebtType'])->name('all_debt_type');
Route::get('/edit-debt/{records}', [DebtController::class, 'edit'])->name('edit_debt');
Route::post('/update-debt/{id}', [DebtController::class, 'update'])->name('update_debt');
Route::post('/delete-debt/{id}', [DebtController::class, 'destroy'])->name('delete_debt');
Route::post('/delete-all-debt', [DebtController::class, 'deleteAllDebt'])->name('delete_all_debt');

//for assets
Route::get('/assets', [AssetController::class, 'index'])->name('asset');
Route::post('/add-asset', [AssetController::class, 'create'])->name('add_asset');
Route::post('/all-asset', [AssetController::class, 'allAssets'])->name('all_asset');
Route::get('/view-asset', [AssetController::class, 'store'])->name('view_asset');
Route::get('/edit-asset/{records}', [AssetController::class, 'edit'])->name('edit_asset');
Route::post('/update-asset/{id}', [AssetController::class, 'update'])->name('update_asset');
Route::post('/delete-asset/{id}', [AssetController::class, 'destroy'])->name('delete_asset');
Route::post('/delete-all-asset', [AssetController::class, 'deleteAllasset'])->name('delete_all_asset');

//for general setting groups
Route::get('/general-setting-groups', [GeneralSettingGroupController::class, 'index'])->name('general_setting_group');
Route::post('/add-general-group', [GeneralSettingGroupController::class, 'create'])->name('add_general_group');
Route::post('/all-general-setting-group', [GeneralSettingGroupController::class, 'AllGeneralSettingGroup'])->name('general_setting_group');
Route::get('/view-general-group', [GeneralSettingGroupController::class, 'store'])->name('view_general_group');
Route::get('/edit-group/{records}', [GeneralSettingGroupController::class, 'edit'])->name('edit_group');
Route::post('/update-general-group/{id}', [GeneralSettingGroupController::class, 'update'])->name('update_general_group');
Route::post('/delete-group/{id}', [GeneralSettingGroupController::class, 'destroy'])->name('delete_group');
Route::post('/delete-multiple-group', [GeneralSettingGroupController::class, 'deleteMultipleGroup'])->name('delete_multiple_group');


//for general settings
Route::get('/general-settings', [GeneralSettingController::class, 'index'])->name('general_setting');
Route::post('/add-general-setting', [GeneralSettingController::class, 'create'])->name('add_general_setting');
Route::post('/all-general-setting', [GeneralSettingController::class, 'AllGeneralSetting'])->name('general_setting');
Route::get('/view-general-setting', [GeneralSettingController::class, 'store'])->name('view_general_setting');
Route::get('/edit-setting/{records}', [GeneralSettingController::class, 'edit'])->name('edit_setting');
Route::post('/update-general-setting/{id}', [GeneralSettingController::class, 'update'])->name('update_general_setting');
Route::post('/delete-general-setting/{id}', [GeneralSettingController::class, 'destroy'])->name('delete_general_setting');
Route::post('/delete-multiple-setting', [GeneralSettingController::class, 'deleteMultipleSetting'])->name('delete_multiple_setting');

//for income outgoing
Route::get('/income-outgoings', [IncomeOutgoingController::class, 'index'])->name('income_outgoing');
Route::post('/add-income-outgoing', [IncomeOutgoingController::class, 'create'])->name('add_income_outgoing');
Route::post('/all-income-outgoings', [IncomeOutgoingController::class, 'allIncomeOutgoings'])->name('all_income_outgoing');
Route::get('/view-income-outgoing', [IncomeOutgoingController::class, 'store'])->name('view_income_outgoing');
Route::get('/edit-income-outgoing/{id}', [IncomeOutgoingController::class, 'edit'])->name('edit_income_outgoing');
Route::post('/update-income-outgoing/{id}', [IncomeOutgoingController::class, 'update'])->name('update_income_outgoing');
Route::post('/delete-income-outgoing/{id}', [IncomeOutgoingController::class, 'destroy'])->name('delete_income_outgoing');
Route::post('/delete-multiple-question', [IncomeOutgoingController::class, 'deleteMultipleQuestion'])->name('delete_multiple_question');
Route::post('/show', [IncomeOutgoingController::class, 'show'])->name('show');
