
 <style>
    table, th, td {
        border: 1px solid black;
        border-spacing: 0px;
    }

</style>
<div class="row">

<div class="col-md-12">

    <div class="card">
        <div class="card-body">
    
            <div class="table-responsive grid-wrapper">

                

                <div id="get_all_agent_data" style="display: block;">
    
                    <table class="table search-table text-center" id="#">
                        <thead>
                            <tr>
                                <th>Agent Name</th>
                                <th>Send IVA</th>
                                <th>Sent To Ip</th>
                                <th>IVA%</th>
                                <th>Send Dmp</th>
                                <th>Sent To DMP Provider</th>
                                <th>DMP%</th>
                            </tr>
                        </thead>
                
                            
                           @foreach($allAgentCount as $key => $value)
                                <tbody>
                                    <td>{{ $key  }}</td>
                                    <td> {{ $value['sendIva'] }} </td>
                                    <td> {{ $value['sendIp'] }} </td>
                                    <td> @if($value['sendIp'] == 0 && $value['sendIva'] == 0) {{ 0 }} @else {{ @(round($value['sendIp'] / $value['sendIva']))  }} @endif %</td>
                                    <td> {{ $value['sendDmp'] }} </td>
                                    <td> {{ $value['sendDmpProvider'] }} </td>
                                    <td> @if($value['sendDmpProvider'] == 0 && $value['sendDmp'] == 0) {{ 0 }} @else {{ @(round($value['sendDmpProvider'] / $value['sendDmp']))  }} @endif %</td>
                                </tbody>
                           @endforeach
                       
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

</div>