{{-- <div class="row">
                    <div class="col-12 col-sm-12 col-md-12 p-0 mt-4">
                        <div class="card card-secondary pt-0 pb-0">
                            <div class="table-responsive">
                                <table class="table search-table text-center data-table" id="full_report" data-ajax-url="{{ route('reports.listfullreportajax') }}">
                                    <thead>
                                        <tr>
                                            <th>User Signin Date</th>
                                            <th>Case No:</th>
                                            <th>Customer Name</th>
                                            <th>Number</th>
                                            <th>Email</th>
                                            <th>Debts Level</th>
                                            <th>Case Status</th>
                                            <th>
                                                Action
                                            </th>
                                        </tr>
                                        </thead>
                                        
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
 
 --}}