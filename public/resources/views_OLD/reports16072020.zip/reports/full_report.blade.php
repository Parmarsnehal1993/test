@extends('layouts.app')



@section('content')

    <!-- main content start -->
@php
    $reportLoginUserData = Auth::user();
    unset($reportLoginUserData->password);

    $reportLoginUser = $reportLoginUserData;
@endphp
    <section class="main-content">

        <div class="container">

            <!-- card details start -->

            <section class="card-details" style="padding: 30px;">

                <h3 style="padding-bottom: 20px;

            font-weight: 700;" id="totalDebtsAmount">Full report
                    
                    @if($reportLoginUser->user_type == 1)
                    <span class="ml-1">
                        <!-- <a class="btn btn-default-outlined font-weight-bold" href="{{ route('downloadReport.pdf', 'full') }}">
                        <i class="fa fa-file-pdf-o"></i>
                        Download
                        
                            PDF</a>
                         -->
                        <a class="btn btn-default-outlined font-weight-bold" href="{{ route('downloadReport.excel', 'full') }}">
                        <i class="fa fa-file-excel-o"></i>
                        Download Excel</a>
                    </span>
                    @endif

                </h3>

                @include('reports.masters.__full')

            </section>

            <!-- card details end -->

        </div>

    </section>

    <script>

        $('#full_report').DataTable({
            searching: true,
            ordering: false
        });

    </script>

@endsection