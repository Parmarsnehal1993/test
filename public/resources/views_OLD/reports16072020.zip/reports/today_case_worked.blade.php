@extends('layouts.app')

@section('content')

    <!-- main content start -->
@php
    $reportLoginUserData = Auth::user();
    unset($reportLoginUserData->password);

    $reportLoginUser = $reportLoginUserData;
@endphp

<style>

    table, th, td {

        border: 1px solid black;

        border-spacing: 0px;

    }

</style>

<section class="main-content">
        <!-- card details start -->
        <div class="row mt--100">
            <h1 id="totalDebtsAmount">Today case Download</h1>
        </div>
            <section class="card-details">
                
                <div class="row mt-5">
                    <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                        <div class="row">
                            <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-6">
                                <div class="row">
                                    <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                                            <form action="{{ route('report.today_case_worked') }}" method="get">
                                                @csrf
                                                <input type="hidden" name="agent_new_id" value="" id="agent_new_id">
                                                
                                                <div class="row">
                                                    <div class="col-6">
                                                    <div class="form-group d-fl ex">
                                                    <input type="text" class="date_range_picker form-control"   id="date_range" name="date_range" placeholder="Select Date:"   autocomplete="off" value="{{ request()->get('date_range') ?? '' }}" autocomplete="off" placeholder="Date">
                                                    <input type="submit" name="submit" value="search" class="btn btn-bordered-primary btn-large btn-outline-info ml-3">
                                                </div>
                                                
                                            </div>
                                            
                                            <div class="col-6 pl-0">
                                            <div class="buttons form-group col-12">
                
                                                    
                                                    <a href="#" id="clear_datepicker" class="btn btn-outline-info">Clear</a>
                                                    <a href="#" onclick="goBack()" class="btn btn-outline-info">Back</a>
                                                </div>     
                                            </div>
                                            </div>                           
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <div class="row">
                            {{-- <form action="{{ route('report.case_conversion_iva') }}" method="get">
                            <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-6">
                                <div class="row">
                                    <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                                        <input type="text" class="date_range_picker form-control" id="date_range" name="date_range" placeholder="Select Date:"   autocomplete="off" value="{{ request()->get('date_range') ?? '' }}" autocomplete="off" placeholder="Date">
                                        <input type="submit" name="submit" value="search">
                                    </div>
                                </div>
                            </div>
                            </form> --}}
                            
                        </div>
                    </div>
                    {{-- {{route('downloadReport.excel' , 'Debt-agent-case-report')}} --}}
                    <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 pr-0 mb-3">
                        <div class="buttons float-right float-md-left float-lg-left float-xl-right small-buttons">
                            <a href="{{ route('downloadReport.excel', 'today_case_worked') }}" class="btn btn-outline-info btn-bordered-primary">
                                <i class="fa fa-file-excel"></i>
                                &nbsp; Export Excel</a>
                        </div>
                    </div>
                   

                        
                </div>

               
                    
                @include('reports.masters.__today_case_worked')
   

        </section>

            

        </div>

    </section>

    <script>

        $('#today_Case_report').DataTable({
            searching: false,
            ordering: false
        });
        $('#search').keyup(function(){
                table.search($(this).val()).draw();
            });


    </script>
    <script>
        function goBack() {
          window.history.back();
        }
    </script>
    <script>
         $(document).on('click','#clear_datepicker',function(){
            var $dates = $('#date_range').datepicker();
            $dates.datepicker('setDate', null);
            });
    </script>
@endsection