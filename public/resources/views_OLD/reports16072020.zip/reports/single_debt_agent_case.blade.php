@extends('layouts.app')

@section('content')

    <!-- main content start -->
@php
    $reportLoginUserData = Auth::user();
    unset($reportLoginUserData->password);

    $reportLoginUser = $reportLoginUserData;
@endphp

<section class="main-content">
        <!-- card details start -->
    <div class="row mt--100">
        <h1 id="totalDebtsAmount">Individual Debt Advisor Cases Worked</h1>
    </div>
            <section class="card-details">
                
                <div class="row mt-5">
                    <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                        <div class="row">
                            <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-6">
                                <div class="row">
                                    <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                                            <form action="{{ route('report.get_ajax_Da_case_report') }}" method="post">
                                                @csrf
                                                <input type="hidden" name="agent_new_id" value="" id="agent_new_id">
                                                <input type="hidden" name="agent_name" value="{{ $agent_name }}" id="agent_name">
                                                <div class="row">
                                                    <div class="col-6">
                                                    <div class="form-group d-flex">
                                                    <input type="text" class="date_range_picker form-control"   id="date_range" name="date_range" placeholder="Select Date:"   autocomplete="off" value="{{ request()->get('date_range') ?? '' }}" autocomplete="off" placeholder="Date">
                                                    <input type="submit" name="submit" value="search" class="btn btn-bordered-primary btn-large btn-outline-info ml-3">
                                                </div>
                                                
                                            </div>
                                            
                                            <div class="col-6 pl-0">
                                            <div class="buttons form-group col-12">

                                                    
                                                    <a href="#" class="btn btn-outline-info">Clear</a>
                                                    <a href="#" onclick="goBack()" class="btn btn-outline-info">Back</a>
                                                </div>     
                                            </div>
                                            </div>                           
                                        </form>
                                    </div>
                                </div>
                            </div>
                           
                        </div>
                    </div>

                    <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 pr-0 mb-3">
                        <div class="buttons float-right float-md-left float-lg-left float-xl-right   small-buttons">
                            <form action="{{ route('report.download_da_report') }}" method="post" >
                            {{-- <a href="" class="btn btn-outline-info btn-bordered-primary">
                                <i class="fa fa-file-excel"></i>
                                &nbsp; Export Excel
                            </a> --}}
                            <inpu type="submit" name="submit" value="export excel">
                            </form>
                        </div>
                    </div>
                        
                </div>

                <style>
                    table, th, td {
                        border: 1px solid black;
                        border-spacing: 0px;
                    }
                </style>
                <div class="row">
                
                    <div class="col-md-12">
                
                        <div class="card">
                        <div class="card-body">
                
                        <div class="table-responsive grid-wrapper">

                            <div id="get_ajax_agent_data" style="display: none;"></div>

                            <div id="get_all_agent_data" style="display: block;">
                
                                <table class="table search-table text-center border-0" id="#">
                                    <thead>
                                        <tr>
                                            <th>Date</th>
                                            <th>Agent Name</th>
                                            <th>Send IVA</th>
                                            <th>Send DMP</th>
                                            <th>Awaiting Docs</th>
                                            <th>ADNC DAY1</th>
                                            <th>ADNC DAY2</th>
                                            <th>ADNC DAY3</th>
                                            <th>ADNC DAY4</th>
                                            <th>In Process</th>
                                            <th>IPNC Day1</th>
                                            <th>IPNC Day2</th>
                                            <th>IPNC Day3</th>
                                            <th>IPNC Day4</th>
                                            <th>Messageday1</th>
                                            <th>Messageday2</th>
                                            <th>Messageday3</th>
                                            <th>Messageday4</th>
                                            <th>Not Intrested</th>
                                            <th>DNC</th>
                                            <th>DRO</th>
                                            <th>Total</th>
                                        </tr>
                                    </thead>
                                    <tbody> 
                                        @php
                                            $ymd_start_date = date_create(date('Y-m-d', strtotime($start_date)));
                                            $ymd_end_date = date_create(date('Y-m-d', strtotime($end_date)));
                                            $matchDate = date('d/m/Y', strtotime($end_date));
                                            $days =date_diff($ymd_start_date, $ymd_end_date)->format("%a");
                                        
                                            $allColumnTotal = 0;
                                            $columnTotal = array();
                                            $columnTotal['sendIva'] = 0;
                                            $columnTotal['sendDmp'] = 0;
                                            $columnTotal['sendAwaitingDocs'] = 0;
                                            $columnTotal['sendawaitingdocsday1'] = 0;
                                            $columnTotal['sendawaitingdocsday2'] = 0;
                                            $columnTotal['sendawaitingdocsday3'] = 0;
                                            $columnTotal['sendawaitingdocsday4'] = 0;
                                            $columnTotal['sendInProcess'] = 0;
                                            $columnTotal['sendinprocessday1'] = 0;
                                            $columnTotal['sendinprocessday2'] = 0;
                                            $columnTotal['sendinprocessday3'] = 0;
                                            $columnTotal['sendinprocessday4'] = 0;
                                            $columnTotal['sendMessageday1'] = 0;
                                            $columnTotal['sendMessageday2'] = 0;
                                            $columnTotal['sendMessageday3'] = 0;
                                            $columnTotal['sendMessageday4'] = 0;
                                            $columnTotal['sendNotIntrested'] = 0;
                                            $columnTotal['sendDnc'] = 0;
                                            $columnTotal['sendDro'] = 0;
                                        @endphp
                                        @for($dataCount = $days; $dataCount >= 0; $dataCount--)
                                            @php
                                                $rowTotal = 0;
                                            @endphp
                                            @if(isset($getSingleAgentData['sendIva'][$matchDate]) || isset($getSingleAgentData['sendDmp'][$matchDate]) || isset($getSingleAgentData['sendAwaitingDocs'][$matchDate]) ||isset($getSingleAgentData['sendawaitingdocsday1'][$matchDate]) || isset($getSingleAgentData['sendawaitingdocsday1
                                            2'][$matchDate]) || isset($getSingleAgentData['sendawaitingdocsday3'][$matchDate]) ||isset($getSingleAgentData['sendawaitingdocsday4'][$matchDate]) || isset($getSingleAgentData['sendInProcess'][$matchDate]) || isset($getSingleAgentData['sendinprocessday1'][$matchDate]) ||isset($getSingleAgentData['sendinprocessday2'][$matchDate]) || isset($getSingleAgentData['sendinprocessday3'][$matchDate]) || isset($getSingleAgentData['sendinprocessday4'][$matchDate]) ||isset($getSingleAgentData['sendMessageday1'][$matchDate]) || isset($getSingleAgentData['sendMessageday2'][$matchDate]) || isset($getSingleAgentData['sendMessageday3'][$matchDate]) ||isset($getSingleAgentData['sendMessageday4'][$matchDate]) || isset($getSingleAgentData['sendNotIntrested'][$matchDate]) || isset($getSingleAgentData['sendDnc'][$matchDate]) || isset($getSingleAgentData['sendDro'][$matchDate]))
                                                <tr>
                                                    <td>{{  $matchDate  }}</td>
                                                    <td class="get_agent_value">{{ $getSingleAgentData['agent_name']  }}</td> 
                                                    <td>
                                                        @if(isset($getSingleAgentData['sendIva'][$matchDate]))
                                                            {{ $getSingleAgentData['sendIva'][$matchDate] }}
                                                            @php
                                                                $columnTotal['sendIva'] += $getSingleAgentData['sendIva'][$matchDate];
                                                                $rowTotal += $getSingleAgentData['sendIva'][$matchDate];

                                                                $allColumnTotal += $getSingleAgentData['sendIva'][$matchDate];
                                                            @endphp
                                                        @else
                                                            {{ 0 }}
                                                        @endif
                                                    </td>

                                                    <td>
                                                        @if(isset($getSingleAgentData['sendDmp'][$matchDate]))
                                                            {{ $getSingleAgentData['sendDmp'][$matchDate] }}
                                                            @php
                                                                $columnTotal['sendDmp'] += $getSingleAgentData['sendDmp'][$matchDate];
                                                                $rowTotal += $getSingleAgentData['sendDmp'][$matchDate];

                                                                $allColumnTotal += $getSingleAgentData['sendDmp'][$matchDate];
                                                            @endphp
                                                        @else
                                                            {{ 0 }}
                                                        @endif
                                                    </td>

                                                    <td>
                                                        @if(isset($getSingleAgentData['sendAwaitingDocs'][$matchDate]))
                                                            {{ $getSingleAgentData['sendAwaitingDocs'][$matchDate] }}
                                                            @php
                                                                $columnTotal['sendAwaitingDocs'] += $getSingleAgentData['sendAwaitingDocs'][$matchDate];
                                                                $rowTotal += $getSingleAgentData['sendAwaitingDocs'][$matchDate];

                                                                $allColumnTotal += $getSingleAgentData['sendAwaitingDocs'][$matchDate];
                                                            @endphp
                                                        @else
                                                            {{ 0 }}
                                                        @endif
                                                    </td>

                                                    <td>
                                                        @if(isset($getSingleAgentData['sendawaitingdocsday1'][$matchDate]))
                                                            {{ $getSingleAgentData['sendawaitingdocsday1'][$matchDate] }}
                                                            @php
                                                                $columnTotal['sendawaitingdocsday1'] += $getSingleAgentData['sendawaitingdocsday1'][$matchDate];
                                                                $rowTotal += $getSingleAgentData['sendawaitingdocsday1'][$matchDate];

                                                                $allColumnTotal += $getSingleAgentData['sendawaitingdocsday1'][$matchDate];
                                                            @endphp
                                                        @else
                                                            {{ 0 }}
                                                        @endif
                                                    </td>

                                                    <td>
                                                        @if(isset($getSingleAgentData['sendawaitingdocsday2'][$matchDate]))
                                                            {{ $getSingleAgentData['sendawaitingdocsday2'][$matchDate] }}
                                                            @php
                                                                $columnTotal['sendawaitingdocsday2'] += $getSingleAgentData['sendawaitingdocsday2'][$matchDate];
                                                                $rowTotal += $getSingleAgentData['sendawaitingdocsday2'][$matchDate];

                                                                $allColumnTotal += $getSingleAgentData['sendawaitingdocsday2'][$matchDate];
                                                            @endphp
                                                        @else
                                                            {{ 0 }}
                                                        @endif
                                                    </td>

                                                    <td>
                                                        @if(isset($getSingleAgentData['sendawaitingdocsday3'][$matchDate]))
                                                            {{ $getSingleAgentData['sendawaitingdocsday3'][$matchDate] }}
                                                            @php
                                                                $columnTotal['sendawaitingdocsday3'] += $getSingleAgentData['sendawaitingdocsday3'][$matchDate];
                                                                $rowTotal += $getSingleAgentData['sendawaitingdocsday3'][$matchDate];

                                                                $allColumnTotal += $getSingleAgentData['sendawaitingdocsday3'][$matchDate];
                                                            @endphp
                                                        @else
                                                            {{ 0 }}
                                                        @endif
                                                    </td>

                                                    <td>
                                                        @if(isset($getSingleAgentData['sendawaitingdocsday4'][$matchDate]))
                                                            {{ $getSingleAgentData['sendawaitingdocsday4'][$matchDate] }}
                                                            @php
                                                                $columnTotal['sendawaitingdocsday4'] += $getSingleAgentData['sendawaitingdocsday4'][$matchDate];
                                                                $rowTotal += $getSingleAgentData['sendawaitingdocsday4'][$matchDate];

                                                                $allColumnTotal += $getSingleAgentData['sendawaitingdocsday4'][$matchDate];
                                                            @endphp
                                                        @else
                                                            {{ 0 }}
                                                        @endif
                                                    </td>

                                                    <td>
                                                        @if(isset($getSingleAgentData['sendInProcess'][$matchDate]))
                                                            {{ $getSingleAgentData['sendInProcess'][$matchDate] }}
                                                            @php
                                                                $columnTotal['sendInProcess'] += $getSingleAgentData['sendInProcess'][$matchDate];
                                                                $rowTotal += $getSingleAgentData['sendInProcess'][$matchDate];

                                                                $allColumnTotal += $getSingleAgentData['sendInProcess'][$matchDate];
                                                            @endphp
                                                        @else
                                                            {{ 0 }}
                                                        @endif
                                                    </td>

                                                    <td>
                                                        @if(isset($getSingleAgentData['sendinprocessday1'][$matchDate]))
                                                            {{ $getSingleAgentData['sendinprocessday1'][$matchDate] }}
                                                            @php
                                                                $columnTotal['sendinprocessday1'] += $getSingleAgentData['sendinprocessday1'][$matchDate];
                                                                $rowTotal += $getSingleAgentData['sendinprocessday1'][$matchDate];

                                                                $allColumnTotal += $getSingleAgentData['sendinprocessday1'][$matchDate];
                                                            @endphp
                                                        @else
                                                            {{ 0 }}
                                                        @endif
                                                    </td>
                                                    <td>
                                                        @if(isset($getSingleAgentData['sendinprocessday2'][$matchDate]))
                                                            {{ $getSingleAgentData['sendinprocessday2'][$matchDate] }}
                                                            @php
                                                                $columnTotal['sendinprocessday2'] += $getSingleAgentData['sendinprocessday2'][$matchDate];
                                                                $rowTotal += $getSingleAgentData['sendinprocessday2'][$matchDate];

                                                                $allColumnTotal += $getSingleAgentData['sendinprocessday2'][$matchDate];
                                                            @endphp
                                                        @else
                                                            {{ 0 }}
                                                        @endif
                                                    </td>

                                                    <td>
                                                        @if(isset($getSingleAgentData['sendinprocessday3'][$matchDate]))
                                                            {{ $getSingleAgentData['sendinprocessday3'][$matchDate] }}
                                                            @php
                                                                $columnTotal['sendinprocessday3'] += $getSingleAgentData['sendinprocessday3'][$matchDate];
                                                                $rowTotal += $getSingleAgentData['sendinprocessday3'][$matchDate];

                                                                $allColumnTotal += $getSingleAgentData['sendinprocessday3'][$matchDate];
                                                            @endphp
                                                        @else
                                                            {{ 0 }}
                                                        @endif
                                                    </td>

                                                    <td>
                                                        @if(isset($getSingleAgentData['sendinprocessday4'][$matchDate]))
                                                            {{ $getSingleAgentData['sendinprocessday4'][$matchDate] }}
                                                            @php
                                                                $columnTotal['sendinprocessday4'] += $getSingleAgentData['sendinprocessday4'][$matchDate];
                                                                $rowTotal += $getSingleAgentData['sendinprocessday4'][$matchDate];

                                                                $allColumnTotal += $getSingleAgentData['sendinprocessday4'][$matchDate];
                                                            @endphp
                                                        @else
                                                            {{ 0 }}
                                                        @endif
                                                    </td>

                                                    <td>
                                                        @if(isset($getSingleAgentData['sendMessageday1'][$matchDate]))
                                                            {{ $getSingleAgentData['sendMessageday1'][$matchDate] }}
                                                            @php
                                                                $columnTotal['sendMessageday1'] += $getSingleAgentData['sendMessageday1'][$matchDate];
                                                                $rowTotal += $getSingleAgentData['sendMessageday1'][$matchDate];

                                                                $allColumnTotal += $getSingleAgentData['sendMessageday1'][$matchDate];
                                                            @endphp
                                                        @else
                                                            {{ 0 }}
                                                        @endif
                                                    </td>

                                                    <td>
                                                        @if(isset($getSingleAgentData['sendMessageday2'][$matchDate]))
                                                            {{ $getSingleAgentData['sendMessageday2'][$matchDate] }}
                                                            @php
                                                                $columnTotal['sendMessageday2'] += $getSingleAgentData['sendMessageday2'][$matchDate];
                                                                $rowTotal += $getSingleAgentData['sendMessageday2'][$matchDate];

                                                                $allColumnTotal += $getSingleAgentData['sendMessageday2'][$matchDate];
                                                            @endphp
                                                        @else
                                                            {{ 0 }}
                                                        @endif
                                                    </td>
                                                    
                                                    <td>
                                                        @if(isset($getSingleAgentData['sendMessageday3'][$matchDate]))
                                                            {{ $getSingleAgentData['sendMessageday3'][$matchDate] }}
                                                            @php
                                                                $columnTotal['sendMessageday3'] += $getSingleAgentData['sendMessageday3'][$matchDate];
                                                                $rowTotal += $getSingleAgentData['sendMessageday3'][$matchDate];

                                                                $allColumnTotal += $getSingleAgentData['sendMessageday3'][$matchDate];
                                                            @endphp
                                                        @else
                                                            {{ 0 }}
                                                        @endif
                                                    </td>

                                                    <td>
                                                        @if(isset($getSingleAgentData['sendMessageday4'][$matchDate]))
                                                            {{ $getSingleAgentData['sendMessageday4'][$matchDate] }}
                                                            @php
                                                                $columnTotal['sendMessageday4'] += $getSingleAgentData['sendMessageday4'][$matchDate];
                                                                $rowTotal += $getSingleAgentData['sendMessageday4'][$matchDate];

                                                                $allColumnTotal += $getSingleAgentData['sendMessageday4'][$matchDate];
                                                            @endphp
                                                        @else
                                                            {{ 0 }}
                                                        @endif
                                                    </td>

                                                    <td>
                                                        @if(isset($getSingleAgentData['sendNotIntrested'][$matchDate]))
                                                            {{ $getSingleAgentData['sendNotIntrested'][$matchDate] }}
                                                            @php
                                                                $columnTotal['sendNotIntrested'] += $getSingleAgentData['sendNotIntrested'][$matchDate];
                                                                $rowTotal += $getSingleAgentData['sendNotIntrested'][$matchDate];

                                                                $allColumnTotal += $getSingleAgentData['sendNotIntrested'][$matchDate];
                                                            @endphp
                                                        @else
                                                            {{ 0 }}
                                                        @endif
                                                    </td>

                                                    <td>
                                                        @if(isset($getSingleAgentData['sendDnc'][$matchDate]))
                                                            {{ $getSingleAgentData['sendDnc'][$matchDate] }}
                                                            @php
                                                                $columnTotal['sendDnc'] += $getSingleAgentData['sendDnc'][$matchDate];
                                                                $rowTotal += $getSingleAgentData['sendDnc'][$matchDate];

                                                                $allColumnTotal += $getSingleAgentData['sendDnc'][$matchDate];
                                                            @endphp
                                                        @else
                                                            {{ 0 }}
                                                        @endif
                                                    </td>

                                                    <td>
                                                        @if(isset($getSingleAgentData['sendDro'][$matchDate]))
                                                            {{ $getSingleAgentData['sendDro'][$matchDate] }}
                                                            @php
                                                                $columnTotal['sendDro'] += $getSingleAgentData['sendDro'][$matchDate];
                                                                $rowTotal += $getSingleAgentData['sendDro'][$matchDate];

                                                                $allColumnTotal += $getSingleAgentData['sendDro'][$matchDate];
                                                            @endphp
                                                        @else
                                                            {{ 0 }}
                                                        @endif
                                                    </td>
                                                    <td> {{ $rowTotal }} </td>
                                                </tr>
                                                @endif
                                                @php
                                                    $matchDate = str_replace('/', '-', $matchDate);
                                                    $tempMatchDate = date('Y-m-d', strtotime($matchDate . ' -1 day'));
                                                    $matchDate = date('d/m/Y', strtotime($tempMatchDate));
                                                @endphp
                                        @endfor
                                                <td>Total</td>
                                                <td>-</td> 
                                                <td>{{ isset($columnTotal['sendIva']) ? $columnTotal['sendIva'] : 0 }}</td>
                                                <td>{{ isset($columnTotal['sendDmp']) ? $columnTotal['sendDmp'] : 0 }}</td>
                                                <td>{{ isset($columnTotal['sendAwaitingDocs']) ? $columnTotal['sendAwaitingDocs'] : 0 }}</td>
                                                <td>{{ isset($columnTotal['sendawaitingdocsday1']) ? $columnTotal['sendawaitingdocsday1'] : 0 }}</td>
                                                <td>{{ isset($columnTotal['sendawaitingdocsday2']) ? $columnTotal['sendawaitingdocsday2'] : 0 }}</td>
                                                <td>{{ isset($columnTotal['sendawaitingdocsday3']) ? $columnTotal['sendawaitingdocsday3'] : 0 }}</td>
                                                <td>{{ isset($columnTotal['sendawaitingdocsday4']) ? $columnTotal['sendawaitingdocsday4'] : 0 }}</td>
                                                <td>{{ isset($columnTotal['sendInProcess']) ? $columnTotal['sendInProcess'] : 0 }}</td>
                                                <td>{{ isset($columnTotal['sendinprocessday1']) ? $columnTotal['sendinprocessday1'] : 0 }}</td>
                                                <td>{{ isset($columnTotal['sendinprocessday2']) ? $columnTotal['sendinprocessday2'] : 0 }}</td>
                                                <td>{{ isset($columnTotal['sendinprocessday3']) ? $columnTotal['sendinprocessday3'] : 0 }}</td>
                                                <td>{{ isset($columnTotal['sendinprocessday4']) ? $columnTotal['sendinprocessday4'] : 0 }}</td>
                                                <td>{{ isset($columnTotal['sendMessageday1']) ? $columnTotal['sendMessageday1'] : 0 }}</td>
                                                <td>{{ isset($columnTotal['sendMessageday2']) ? $columnTotal['sendMessageday2'] : 0 }}</td>
                                                <td>{{ isset($columnTotal['sendMessageday3']) ? $columnTotal['sendMessageday3'] : 0 }}</td>
                                                <td>{{ isset($columnTotal['sendMessageday4']) ? $columnTotal['sendMessageday4'] : 0 }}</td>
                                                <td>{{ isset($columnTotal['sendNotIntrested']) ? $columnTotal['sendNotIntrested'] : 0 }}</td>
                                                <td>{{ isset($columnTotal['sendDnc']) ? $columnTotal['sendDnc'] : 0 }}</td>
                                                <td>{{ isset($columnTotal['sendDro']) ? $columnTotal['sendDro'] : 0 }}</td>
                                                <td> {{ $allColumnTotal }} </td>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
                
         </div>
   

        </section>

            <!-- card details end -->

        </div>

    </section>

    <script type="text/javascript">
        $(document).ready(function(){
            
            $( ".datepicker" ).datepicker(
                {
            changeMonth: true,
            changeYear: true,
            dateFormat: 'mm/dd/yy',
            beforeShow: function (input, inst) {
                var rect = input.getBoundingClientRect();
                setTimeout(function () {
                    inst.dpDiv.css({ top: rect.top + 40, left: rect.left + 0 });
                }, 0);
            }});
        });
        </script>

    <script>

        $('#advisor_send_to_drafter_case_report').DataTable({
            searching: false,
            ordering: false
        });
        $('#search').keyup(function(){
                table.search($(this).val()).draw();
            });


    </script>

    <script>
        $(document).ready(function(){
            var agent_name_get = $('.get_agent_value').text();
            $('#agent_new_id').val(agent_name_get);
            
        });
    </script>
    
    <script>
function goBack() {
  window.history.back();
}
</script>


@endsection