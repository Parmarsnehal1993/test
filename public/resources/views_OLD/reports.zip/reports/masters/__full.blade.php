<div class="row"> 
    <div class="col-md-12">
        <div class="table-responsive grid-wrapper">
            <table class="table-grid table-bordered table-pd" id="full_report">
                <thead>
                <tr>
                    <th>Customer Name</th>
                    <th>Number</th>
                    <th>Email</th>
                    <th>DOB</th>
                    <th>Debt Level</th>
                    <th>Total Debt</th>
                    <th>Employment</th>
                    <th>Living Arrangements</th>
                    <th>Downloaded Date</th>
                    <th>Completed Date</th>
                    <th>Case Status</th>
                    <th>Solution Type</th>
                </tr>
                </thead>
            </table>
        </div>
    </div>
</div>