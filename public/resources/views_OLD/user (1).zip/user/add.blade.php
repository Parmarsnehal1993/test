@extends('layouts.app')

@section('content')


{{-- @include('user.userInfo') --}}
@include('user.user_common_details');

@endsection	