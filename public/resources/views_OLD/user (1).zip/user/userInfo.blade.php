
<div class="card-body">
       @foreach($userListSignupQuestions as $data)
        <form method="post" action="#"> 
            <div class="form-group">
                <input type="text" class="form-control" placeholder="First Name:" value="{{ !empty($userInfo->name) ? $userInfo->name : '' }}">
            </div>
            <div class="form-group">
                <input type="text" class="form-control" placeholder="Last Name:" value="{{ !empty($userInfo->surname) ? $userInfo->surname : '' }}">
            </div>
            <div class="form-group">
                <input type="text" class="form-control" placeholder="D.O.B:" value="{{ !empty($data->birthDay) ? date('Y-m-d', strtotime($data->birthDay)) : '' }}">
            </div>
            <div class="form-group">
                <input type="email" class="form-control" placeholder="E-Mail:" value="{{ !empty($userInfo->email) ? $userInfo->email : '' }}">
            </div>
        </form>
       
     @endforeach
</div>
<div class="plus-sign" data-toggle="modal" data-backdrop="static" data-keyboard="false" data-target="#personal_detail_model">
    <img src="{!! asset('images/icons/Plus_Icon@2x.png')!!}" alt="Add" width="30">
</div>
<div id="personal_detail_model" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="my-modal-title" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        @if(Route::currentRouteName() != 'addUser')
            <div class="modal-content card card-secondary">
                <div class="modal-header">
                    <div class="card-title">
                        Personal details
                    </div>
                    <button type="button" class="close alert_open" aria-label="Close">
                        <img
                            src="{!! asset('images/icons/Cross_Icon@2x.png')!!}"
                            alt="Close"
                            class="img-fulid"
                            width="40"
                            height="40">
                    </button>
                </div>
                @foreach($userListSignupQuestions as $result)
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-9">
                            <div class="row">
                                <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                                    {{-- <form action="#" method="post" class="user_form">
                                        @csrf --}}
                                        {{-- <input type="hidden" name="userId" id="userId" value="{{ $userInfo->user_id }}"> --}}
                                        <div class="form-group">
                                            <label for="f_name">First Name:</label>
                                            <input
                                                id="f_name"
                                                class="form-control"
                                                type="text"
                                                name="f_name"
                                                placeholder="First Name" value="{{ !empty($userInfo->name) ? $userInfo->name : '' }}">
                                        </div>
                                        <div class="form-group">
                                        <label for="l_name">Last Name:</label>
                                            <input
                                                id="l_name"
                                                class="form-control"
                                                type="text"
                                                name="l_name"
                                                placeholder="Last Name" value="{{ !empty($userInfo->surname) ? $userInfo->surname : '' }}">
                                        </div>
                                        <div class="form-group">
                                        <label for="birthDay">D.O.B.:</label>
                                            <input
                                                type="text"
                                                id="birthDay"
                                                class="form-control datepicker"
                                                name="birthDay"
                                                placeholder="D.O.B." value="{{ !empty($result->birthDay) ? date('Y-m-d', strtotime($result->birthDay)) : '' }}">
                                        </div>
                                        <div class="form-group">
                                        <label for="email">Email:</label>
                                            <input
                                                id="email"
                                                class="form-control"
                                                type="email"
                                                name="email"
                                                placeholder="Email" value="{{ !empty($userInfo->email) ? $userInfo->email : '' }}">
                                        </div>
                                        <div class="form-group">
                                        <label for="houseNumber">House No.:</label>
                                            <input
                                                id="houseNumber"
                                                class="form-control"
                                                type="text"
                                                name="houseNumber"
                                                placeholder="House No." value="{{ !empty($result->houseNumber) ? $result->houseNumber : '' }}">
                                        </div>
                                        <div class="form-group">
                                        <label for="address">Address:</label>
                                            <input
                                                id="address"
                                                class="form-control"
                                                type="text"
                                                name="address"
                                                placeholder="Address" value="{{ !empty($result->address) ? $result->address : '' }}">
                                        </div>
                                        <div class="form-group">
                                        <label for="country">Country:</label>
                                            <input
                                                id="country"
                                                class="form-control"
                                                type="text"
                                                name="country"
                                                placeholder="Country"
                                                 value="{{ !empty($result->country) ? $result->country : '' }}">
                                        </div>
                                        <div class="form-group">
                                        <label for="postCode">Postcode:</label>
                                            <input
                                                id="postCode"
                                                class="form-control"
                                                type="number"
                                                name="postCode"
                                                placeholder="Postcode" value="{{ !empty($result->postCode) ? $result->postCode : '' }}">
                                        </div>
                                
                                </div>
                                <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                                    {{-- <form action="#"> --}}
                                        <div class="form-group">
                                        <label for="EmpStatus">Employment:</label>
                                            <input
                                                id="EmpStatus"
                                                class="form-control"
                                                type="text"
                                                name="EmpStatus"
                                                placeholder="Employment:" value="{{ !empty($result->EmpStatus) ? $result->EmpStatus : '' }}">
                                        </div>
                                        <div class="form-group">
                                        <label for="rentOrOwnHome">Living Arrangement:</label>
                                            <input
                                                id="rentOrOwnHome"
                                                class="form-control"
                                                type="text"
                                                name="rentOrOwnHome"
                                                placeholder="Living Arrangement:" value="{{ !empty($result->rentOrOwnHome) ? $result->rentOrOwnHome : '' }}">
                                        </div>
                                        <div class="form-group">
                                        <label for="haveCar">Car:</label>
                                            <input id="haveCar" class="form-control" type="text" name="haveCar" placeholder="Car:" value="{{ !empty($result->haveCar) ? $result->haveCar : '' }}">
                                        </div>
                                        <div class="form-group">
                                        <label for="isFinanced">Is Financed:</label>
                                            <input
                                                id="isFinanced"
                                                class="form-control"
                                                type="text"
                                                name="isFinanced"
                                                placeholder="Is Financed:" value="{{ !empty($result->isFinanced) ? $result->isFinanced : '' }}">
                                        </div>
                                        <div class="form-group">
                                        <label for="havePets">Pet:</label>
                                            <input id="havePets" class="form-control" type="text" name="havePets" placeholder="Pet:" value="{{ !empty($result->havePets) ? $result->havePets : '' }}">
                                        </div>
                                        <div class="form-group">
                                        <label for="child14To18">Childern 14-18:</label>
                                            <input
                                                id="child14To18"
                                                class="form-control"
                                                type="text"
                                                name="child14To18"
                                                placeholder="Childern 14-18:" value="{{ !empty($result->child14To18) ? $result->child14To18 : '' }}">
                                        </div>
                                        <div class="form-group">
                                        <label for="childUnder14">Childern under 14:</label>
                                            <input
                                                id="childUnder14"
                                                class="form-control"
                                                type="text"
                                                name="childUnder14"
                                                placeholder="Childern under 14:" value="{{ !empty($result->childUnder14) ? $result->childUnder14 : '' }}">
                                        </div>
                                        <div class="form-group">
                                        <label for="Is_this_for_you_alone_or_you_and_partner">Single / Joint Solution:</label>
                                            <input
                                                id="Is_this_for_you_alone_or_you_and_partner"
                                                class="form-control"
                                                type="text"
                                                name="Is_this_for_you_alone_or_you_and_partner?"
                                                placeholder="Single / Joint Solution" value="{{ !empty($result->Is_this_for_you_alone_or_you_and_partner) ? $result->Is_this_for_you_alone_or_you_and_partner : '' }}">
                                        </div>
                                    {{--   </form> --}}
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <p style="font-size: 14px;color: #00b0ff;" class="mt-2 mb-0">
                                Accepted T & C:
                            </p>
                            <table class="table mb-0">
                                <tbody>
                                    <tr>
                                        <td class="text-left pl-0">
                                            <div class="custom-control custom-radio custom-control-inline">
                                                <input type="radio" id="modal_yes" name="Debts" class="custom-control-input" value="yes"{{ ($userInfo->is_term=='yes'
                                                ) ? 'checked' : '' }}>
                                                <label class="custom-control-label" for="modal_yes">yes</label>
                                            </div>
                                            <div class="custom-control custom-radio custom-control-inline">
                                                <input type="radio" id="model_no" name="Debts" class="custom-control-input" value="yes"{{($userInfo->is_term=='no') ? 'checked' : '' }}>
                                                <label class="custom-control-label" for="model_no">no</label>
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <p style="font-size: 14px;color: #00b0ff;" class="mt-2 mb-0">
                                Accepted Contact Information:
                            </p>
                            <table class="table mb-0">
                                <tbody>
                                    <tr>
                                        <td class="text-left pl-0">
                                            <div class="custom-control custom-radio custom-control-inline">
                                                <input
                                                    type="radio"
                                                    id="contac_info_yes"
                                                    name="contact_info_radio"
                                                    class="custom-control-input"
                                                    value="yes"{{ ($userInfo->is_contact=='yes'
                                                ) ? 'checked' : '' }}>
                                                <label class="custom-control-label"  for="contac_info_yes">yes</label>
                                            </div>
                                            <div class="custom-control custom-radio custom-control-inline">
                                                <input
                                                    type="radio"
                                                    id="contac_info_no"
                                                    name="contact_info_radio"
                                                    class="custom-control-input"
                                                    value="no"{{($userInfo->is_contact=='no') ? 'checked' : '' }}>
                                                <label class="custom-control-label" for="contac_info_no">no</label>
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                @endforeach
                <div class="modal-body">
                </div>
                <div class="modal-footer mb-5">
                    {{-- <a href="javascipt:void(0)" class="btn btn-outline-info float-right btn-large" data-dismiss="modal" id="update">Update</a> --}}
                    <input type="submit" name="submit" value="Update" class="btn btn-outline-info float-right btn-large" data-dismiss="modal" id="update">
                </div>
                {{-- </form> --}}
            </div>
        @else
            <h4>CUSTOMER DETAILS</h4>
            {{-- <form action="#" method="POST"> --}}
           
            <div class="table-responsive grid-wrapper">
                <table class="bold-table text-normal small-text has-space form-table">
                    <tbody>
                        <tr>
                            <td>NAME:</td>
                            <td><input class="form-control" type="text" name="name" id="name" required></td>
                        </tr>
                        <tr>
                            <td>Mobile:</td>
                            <td><input class="form-control" type="text" name="tel" id="tel" required></td>
                        </tr>
                        <tr>
                            <td>User Case Type:</td>
                            <td>
                                <select id="userCaseType" name="userCaseType" class="form-control" placeholder="User Case Type">
                                    <option value="Live Transfer" class="form-control">Live Transfer</option>
                                    <option value="Web Lead" class="form-control">Web Lead</option>
                                    <option value="Referral" class="form-control">Referral</option>
                                    <option value="IOSAPP" class="form-control">IOSAPP</option>
                                    <option value="ANDAPP" class="form-control">ANDAPP</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td>DOB:</td>
                            <td><input class="form-control datepicker" type="text" name="birthDay" id="birthDay" required></td>
                        </tr>
                        <tr>
                            <td>EMAIL:</td>
                            <td><input class="form-control" type="text" name="email" id="email" required></td>
                        </tr>
                        <tr>
                            <td>EMPOYMENT:</td>
                            <td><input class="form-control" type="text" name="EmpStatus" id="EmpStatus" required></td>
                        </tr>
                        <tr>
                            <td>LIVING ARRANGEMENTS:</td>
                            <td><input class="form-control" type="text" name="rentOrOwnHome" id="rentOrOwnHome" required></td>
                        </tr>
                        <tr>
                            <td>Country:</td>
                            <td><input class="form-control" type="text" name="country" id="country" required></td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="text-right">
                <input type="submit" class="btn btn-primary" id="add_user_info" name="add_user_info" value="Add">
            </div>
                {{-- </form> --}}
        @endif
    </div>
</div>
<script type="text/javascript">
$(document).ready(function(){
    
    $( ".datepicker" ).datepicker(
        {
    changeMonth: true,
    changeYear: true,
    dateFormat: 'mm/dd/yy',
    beforeShow: function (input, inst) {
        var rect = input.getBoundingClientRect();
        setTimeout(function () {
            inst.dpDiv.css({ top: rect.top + 40, left: rect.left + 0 });
        }, 0);
    }});
});
</script>


<script>
$(document).on('click', '#update', function(e){
    e.preventDefault();

    var userId = $('#userId').val();
    var f_name = $('#f_name').val();
    var l_name = $('#l_name').val();
    var birthDay = $('#birthDay').val();
    var email = $('#email').val();
    var houseNumber = $('#houseNumber').val();
    var address = $('#address').val();
    var country = $('#country').val();
    var postCode = $('#postCode').val();
    var EmpStatus = $('#EmpStatus').val();
    var rentOrOwnHome = $('#rentOrOwnHome').val();
    var haveCar = $('#haveCar').val();
    var isFinanced = $('#isFinanced').val();
    var havePets = $('#havePets').val();
    var child14To18 = $('#child14To18').val();
    var childUnder14 = $('#childUnder14').val();
    var Is_this_for_you_alone_or_you_and_partner = $('#Is_this_for_you_alone_or_you_and_partner').val();

    //console.log('userId => ' + userId + ' f_name => '+ f_name +' l_name => '+ l_name +' birthDay => '+ birthDay +' email => '+ email +' houseNumber => '+ houseNumber +' address => '+ address +' country => '+ country +' postCode => '+ postCode +' EmpStatus => '+ EmpStatus +' rentOrOwnHome => '+ rentOrOwnHome +' haveCar => '+ haveCar +' isFinanced => '+ isFinanced +' havePets => '+ havePets +' child14To18 => '+ child14To18 +' childUnder14 => '+ childUnder14 + ' Is_this_for_you_alone_or_you_and_partner => ' +Is_this_for_you_alone_or_you_and_partner);

    $.ajax({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        url:'{{ route('user.update_sigunup_question') }}',
        method:'POST',
        dataType:'json',
        data:{
            "userId" : userId,
            "f_name" : f_name,
            "l_name" : l_name,
            "birthDay" : birthDay,
            "email" : email,
            "houseNumber" : houseNumber,
            "address" : address,
            "country" : country,
            "postCode" : postCode,
            "EmpStatus" : EmpStatus,
            "rentOrOwnHome" : rentOrOwnHome,
            "haveCar" : haveCar,
            "isFinanced" : isFinanced,
            "havePets" : havePets,
            "child14To18" : child14To18,
            "childUnder14" : childUnder14,
            "Is_this_for_you_alone_or_you_and_partner" : Is_this_for_you_alone_or_you_and_partner
        },
        success:function(data)
        {
            var messageIcon = 'error';
            if (data == 'RequiredEmail') {
                var message = 'Email is required';
            } else if (data == 'RequiredBirthdate') {
                var message = 'Birthdate is required';
            } else if (data == 'RequiredEmployment') {
                var message = 'Employment is required';
            } else if (data == 'RequiredLivingArrangement') {
                var message = 'Livinng Arrangement is required';
            } else if (data == 'RequiredCountry') {
                var message = 'Country is required';
            } else if (data == 'success') {
                var message = 'Data Save Successfully';
                var messageIcon = 'success';
            } else {
                var message = 'something wrong please try again';
            }
            swal(message, {
              icon: messageIcon,
            });
        }
    });
});
</script>

