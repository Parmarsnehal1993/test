
 <style>
    table, th, td {
        border: 1px solid black;
        border-spacing: 0px;
    }

</style>
<div class="row">

<div class="col-md-12">

    <div class="card">
        <div class="card-body">
    
            <div class="table-responsive grid-wrapper">

                

                <div id="get_all_agent_data" style="display: block;">
    
                    <table class="table search-table text-center border-0" id="#">
                        <thead>
                            <tr>
                                <th>Agent Name</th>
                                <th>Send IVA</th>
                                <th>Send DMP</th>
                                <th>Awaiting Docs</th>
                                <th>ADNC DAY1</th>
                                <th>ADNC DAY2</th>
                                <th>ADNC DAY3</th>
                                <th>ADNC DAY4</th>
                                <th>In Process</th>
                                <th>IPNC Day1</th>
                                <th>IPNC Day2</th>
                                <th>IPNC Day3</th>
                                <th>IPNC Day4</th>
                                <th>Messageday1</th>
                                <th>Messageday2</th>
                                <th>Messageday3</th>
                                <th>Messageday4</th>
                                <th>Not Intrested</th>
                                <th>DNC</th>
                                <th>DRO</th>
                            </tr>
                        </thead>
                
                        @foreach($finalAllAgent as $innerKey => $innerValue) 
                                <tbody>
                                    <td>{{ $innerKey }}</td>
                                    <td>{{ $innerValue['sendIva'] }}</td>
                                    <td>{{ $innerValue['sendDmp'] }}</td>
                                    <td>{{ $innerValue['sendAwaitingDocs'] }}</td>
                                    <td>{{ $innerValue['sendawaitingdocsday1'] }}</td>
                                    <td>{{ $innerValue['sendawaitingdocsday2'] }}</td>
                                    <td>{{ $innerValue['sendawaitingdocsday3'] }}</td>
                                    <td>{{ $innerValue['sendawaitingdocsday4'] }}</td>
                                    <td>{{ $innerValue['sendInProcess'] }}</td>
                                    <td>{{ $innerValue['sendinprocessday1'] }}</td>
                                    <td>{{ $innerValue['sendinprocessday2'] }}</td>
                                    <td>{{ $innerValue['sendinprocessday3'] }}</td>
                                    <td>{{ $innerValue['sendinprocessday4'] }}</td>
                                    <td>{{ $innerValue['sendMessageday1'] }}</td>
                                    <td>{{ $innerValue['sendMessageday2'] }}</td>
                                    <td>{{ $innerValue['sendMessageday3'] }}</td>
                                    <td>{{ $innerValue['sendMessageday4'] }}</td>
                                    <td>{{ $innerValue['sendNotIntrested'] }}</td>
                                    <td>{{ $innerValue['sendDnc'] }}</td>
                                    <td>{{ $innerValue['sendDro'] }}</td>
                                </tbody>
                        @endforeach
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

</div>