
<div class="card-body">
    <form method="post" action="#"> 
        <div class="form-group">
            <input type="text" class="form-control" placeholder="First Name:" value="{{ !empty($userInfo->name) ? $userInfo->name : '' }}" readonly>
        </div>
        <div class="form-group">
            <input type="text" class="form-control" placeholder="Last Name:" value="{{ !empty($userInfo->surname) ? $userInfo->surname : '' }}" readonly>
        </div>
        @php
            $tempUserListSignupQuestions = collect($userListSignupQuestions)->toArray();
        @endphp
        @if(!empty($tempUserListSignupQuestions))
            @foreach($userListSignupQuestions as $data)
                <div class="form-group">
                    <input type="text" class="form-control" placeholder="D.O.B:" value="{{ !empty($data->birthDay) ? date('Y-m-d', strtotime($data->birthDay)) : '' }}" readonly>
                </div>
            @endforeach
        @else
            <div class="form-group">
                <input type="text" class="form-control" placeholder="D.O.B:" readonly>
            </div>
        @endif
        <div class="form-group">
            <input type="email" class="form-control" placeholder="E-Mail:" value="{{ !empty($userInfo->email) ? $userInfo->email : '' }}" readonly>
        </div>
    </form>
</div>
<div class="plus-sign" data-toggle="modal" data-backdrop="static" data-keyboard="false" data-target="#personal_detail_model">
    <img src="{!! asset('images/icons/Plus_Icon@2x.png')!!}" alt="Add" width="30">
</div>
<div id="personal_detail_model" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="my-modal-title" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content card card-secondary">
                <div class="modal-header">
                    <div class="card-title">
                        Personal details
                    </div>
                    <button type="button" class="close alert_open" aria-label="Close">
                        <img
                            src="{!! asset('images/icons/Cross_Icon@2x.png')!!}"
                            alt="Close"
                            class="img-fulid"
                            width="40"
                            height="40">
                    </button>
                </div>
                @php
                    $tempUserListSignupQuestions = collect($userListSignupQuestions)->toArray();
                @endphp
                @if(!empty($tempUserListSignupQuestions))
                    @foreach($userListSignupQuestions as $result)
                        <div class="modal-body">
                            <div class="row">
                                <div class="col-md-9">
                                    <div class="row">
                                        <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                                            {{-- <form action="#" method="post" class="user_form">
                                                @csrf --}}
                                                {{-- <input type="hidden" name="userId" id="userId" value="{{ $userInfo->user_id }}"> --}}
                                                <div class="form-group">
                                                    <label for="f_name">First Name: <span style="color:red">*</span></label>
                                                    <input
                                                        id="f_name"
                                                        class="form-control"
                                                        type="text"
                                                        name="f_name"
                                                        placeholder="First Name" value="{{ !empty($userInfo->name) ? $userInfo->name : '' }}">
                                                </div>
                                                <div class="form-group">
                                                <label for="l_name">Last Name: <span style="color:red">*</span></label>
                                                    <input
                                                        id="l_name"
                                                        class="form-control"
                                                        type="text"
                                                        name="l_name"
                                                        placeholder="Last Name" value="{{ !empty($userInfo->surname) ? $userInfo->surname : '' }}">
                                                </div>
                                                <div class="form-group">
                                                <label for="birthDay">D.O.B.: <span style="color:red">*</span></label>
                                                    <input
                                                        type="text"
                                                        id="birthDay"
                                                        class="form-control datepicker"
                                                        name="birthDay"
                                                        placeholder="D.O.B." value="{{ !empty($result->birthDay) ? date('Y-m-d', strtotime($result->birthDay)) : '' }}">
                                                </div>
                                                <div class="form-group">
                                                <label for="email">Email: <span style="color:red">*</span></label>
                                                    <input
                                                        id="email"
                                                        class="form-control"
                                                        type="email"
                                                        name="email"
                                                        placeholder="Email" value="{{ !empty($userInfo->email) ? $userInfo->email : '' }}">
                                                </div>
                                                <div class="form-group">
                                                <label for="houseNumber">House No.:</label>
                                                    <input
                                                        id="houseNumber"
                                                        class="form-control"
                                                        type="text"
                                                        name="houseNumber"
                                                        placeholder="House No." value="{{ !empty($result->houseNumber) ? $result->houseNumber : '' }}">
                                                </div>
                                                <div class="form-group">
                                                <label for="address">Address:</label>
                                                    <input
                                                        id="address"
                                                        class="form-control"
                                                        type="text"
                                                        name="address"
                                                        placeholder="Address" value="{{ !empty($result->address) ? $result->address : '' }}">
                                                </div>
                                                <div class="form-group">
                                                <label for="country">Country: <span style="color:red">*</span></label>
                                                
                                                <select class="form-control" id="country" name="country">
                                                    
                                                   @foreach ($country as $Countrykey => $countryvalue)
                                                        @php  $selected_country = ''; @endphp
                                                        @if(isset($result->country) && !empty($result->country) && $result->country == $countryvalue->name)
                                                            @php $selected_country = 'selected'; @endphp
                                                            
                                                        @endif
                                                        <option value="{{ $countryvalue->name }}" {{ $selected_country }}>{{ $countryvalue->display_name }}</option>
                                                    @endforeach
                                                </select>
                                                    {{-- <input
                                                        id="country"
                                                        class="form-control"
                                                        type="text"
                                                        name="country"
                                                        placeholder="Country"
                                                         value="{{ !empty($result->country) ? $result->country : '' }}"> --}}
                                                </div>
                                                <div class="form-group">
                                                <label for="postCode">Postcode:</label>
                                                    <input
                                                        id="postCode"
                                                        class="form-control"
                                                        type="number"
                                                        name="postCode"
                                                        placeholder="Postcode" value="{{ !empty($result->postCode) ? $result->postCode : '' }}">
                                                </div>
                                                <div class="form-group">
                                                    <label for="mobile">Mobile: <span style="color:red">*</span></label>
                                                    <input
                                                        id="mobile"
                                                        class="form-control"
                                                        type="text"
                                                        name="mobile"
                                                        placeholder="Mobile" value="{{ !empty($userInfo->tel) ? $userInfo->tel : '' }}">
                                                </div>
                                        
                                        </div>
                                        <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                                            {{-- <form action="#"> --}}
                                                <div class="form-group">
                                                <label for="EmpStatus">Employment:  <span style="color:red">*</span></label>
                                                        <select name="EmpStatus" id="EmpStatus" class="form-control">
                                                        @foreach($getEmpStatus as $getEmpStatuskey => $getEmpStatusvalue)
                                                            @php  $selected_country = '';  @endphp
                                                            @if(isset($result->EmpStatus) && !empty($result->EmpStatus) && $result->EmpStatus == $getEmpStatusvalue->name)
                                                                @php $selected_country = 'selected'; @endphp
                                                                
                                                            @endif
                                                            <option value="{{ $getEmpStatusvalue->name }}" {{ $selected_country }}>{{ $getEmpStatusvalue->display_name }}</option>
                                                        @endforeach
                                                        </select>
                                                </div>
                                                <div class="form-group">
                                                <label for="rentOrOwnHome">Living Arrangement: <span style="color:red">*</span></label>
                                                 <select id="rentOrOwnHome" name="rentOrOwnHome" class="form-control">
                                                     @foreach ($living_arrangment as $living_arrangment_key => $living_arrangment_value)
                                                        @php  $selected_country = ''; @endphp
                                                        @if(isset($result->rentOrOwnHome) && !empty($result->rentOrOwnHome) && $result->rentOrOwnHome == $living_arrangment_value)
                                                            @php $selected_country = 'selected'; @endphp
                                                            
                                                        @endif
                                                        <option value="{{ $living_arrangment_value }}" {{ $selected_country }}>{{ $living_arrangment_value }}</option>
                                                    @endforeach
                                                        
                                                    </select>    
                                                   
                                                
                                                {{-- <input
                                                        id="rentOrOwnHome"
                                                        class="form-control"
                                                        type="text"
                                                        name="rentOrOwnHome"
                                                        placeholder="Living Arrangement:" value="{{ !empty($result->rentOrOwnHome) ? $result->rentOrOwnHome : '' }}"> --}}
                                                </div>
                                                <div class="form-group">
                                                <label for="haveCar">Car:</label>
                                                    <input id="haveCar" class="form-control" type="text" name="haveCar" placeholder="Car:" value="{{ !empty($result->haveCar) ? $result->haveCar : '' }}">
                                                </div>
                                                <div class="form-group">
                                                <label for="isFinanced">Is Financed:</label>
                                                    <input
                                                        id="isFinanced"
                                                        class="form-control"
                                                        type="text"
                                                        name="isFinanced"
                                                        placeholder="Is Financed:" value="{{ !empty($result->isFinanced) ? $result->isFinanced : '' }}">
                                                </div>
                                                <div class="form-group">
                                                <label for="havePets">Pet:</label>
                                                    <input id="havePets" class="form-control" type="text" name="havePets" placeholder="Pet:" value="{{ !empty($result->havePets) ? $result->havePets : '' }}">
                                                </div>
                                                <div class="form-group">
                                                <label for="child14To18">Childern 14-18:</label>
                                                    <input
                                                        id="child14To18"
                                                        class="form-control"
                                                        type="text"
                                                        name="child14To18"
                                                        placeholder="Childern 14-18:" value="{{ !empty($result->child14To18) ? $result->child14To18 : '' }}">
                                                </div>
                                                <div class="form-group">
                                                <label for="childUnder14">Childern under 14:</label>
                                                    <input
                                                        id="childUnder14"
                                                        class="form-control"
                                                        type="text"
                                                        name="childUnder14"
                                                        placeholder="Childern under 14:" value="{{ !empty($result->childUnder14) ? $result->childUnder14 : '' }}">
                                                </div>
                                                <div class="form-group">
                                                <label for="Is_this_for_you_alone_or_you_and_partner">Single / Joint Solution:</label>
                                                
                                                <select class="form-control" id="Is_this_for_you_alone_or_you_and_partner" name="Is_this_for_you_alone_or_you_and_partner">
                                                    @foreach ($singlejoin as $singlejoinkey => $singlejoinvalue)
                                                        @php  $selected_country = ''; @endphp
                                                        @if(isset($result->is_this_for_you_alone_or_you_and_partner) && !empty($result->is_this_for_you_alone_or_you_and_partner) && $result->is_this_for_you_alone_or_you_and_partner == $singlejoinvalue)
                                                            @php $selected_country = 'selected'; @endphp
                                                            
                                                        @endif
                                                        <option value="{{ $singlejoinvalue }}" {{ $selected_country }}>{{ $singlejoinvalue }}</option>
                                                    @endforeach
                                                    
                                                </select>
                                                   
                                                </div>
                                                <div class="form-group">
                                                    <label for="where_did_you_hear_about_us">Where Did You Hear About Us?</label>
                                                    
                                                    <select class="form-control" id="where_did_you_hear_about_us" name="where_did_you_hear_about_us">
                                                        @foreach ($aboutUs as $aboutUskey => $aboutUsvalue)
                                                            @php  $selected_country = ''; @endphp
                                                            @if(isset($result->where_did_you_hear_about_us) && !empty($result->where_did_you_hear_about_us) && $result->where_did_you_hear_about_us == $aboutUsvalue->name)
                                                                @php $selected_country = 'selected'; @endphp
                                                                
                                                            @endif
                                                            <option value="{{ $aboutUsvalue->name }}" {{ $selected_country }}>{{ $aboutUsvalue->display_name }}</option>
                                                        @endforeach
                                                        
                                                    </select>
                                                    {{-- <input
                                                        id="where_did_you_hear_about_us"
                                                        class="form-control"
                                                        type="text"
                                                        name="where_did_you_hear_about_us?"
                                                        placeholder="Where Did You Hear About Us?" value="{{ !empty($result->where_did_you_hear_about_us) ? $result->where_did_you_hear_about_us : '' }}"> --}}
                                                </div>
                                            {{--   </form> --}}
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <p style="font-size: 14px;color: #00b0ff;" class="mt-2 mb-0">
                                        Accepted T & C:
                                    </p>
                                    <table class="table mb-0">
                                        <tbody>
                                            <tr>
                                                <td class="text-left pl-0">
                                                    <div class="custom-control custom-radio custom-control-inline">
                                                        <input type="radio" id="modal_yes" name="accepted_tearms_and_conditions_radio" class="custom-control-input" value="yes"{{ ($userInfo->is_term=='yes'
                                                        ) ? 'checked' : '' }}>
                                                        <label class="custom-control-label" for="modal_yes">yes</label>
                                                    </div>
                                                    <div class="custom-control custom-radio custom-control-inline">
                                                        <input type="radio" id="model_no" name="accepted_tearms_and_conditions_radio" class="custom-control-input" value="no"{{($userInfo->is_term=='no') ? 'checked' : '' }}>
                                                        <label class="custom-control-label" for="model_no">no</label>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <p style="font-size: 14px;color: #00b0ff;" class="mt-2 mb-0">
                                        Accepted Contact Information:
                                    </p>
                                    <table class="table mb-0">
                                        <tbody>
                                            <tr>
                                                <td class="text-left pl-0">
                                                    <div class="custom-control custom-radio custom-control-inline">
                                                        <input
                                                            type="radio"
                                                            id="contac_info_yes"
                                                            name="contact_info_radio"
                                                            class="custom-control-input"
                                                            value="yes" {{ ($userInfo->is_contact=='yes'
                                                        ) ? 'checked' : '' }}>
                                                        <label class="custom-control-label"  for="contac_info_yes">yes</label>
                                                    </div>
                                                    <div class="custom-control custom-radio custom-control-inline">
                                                        <input
                                                            type="radio"
                                                            id="contac_info_no"
                                                            name="contact_info_radio"
                                                            class="custom-control-input"
                                                            value="no" {{ ($userInfo->is_contact=='no') ? 'checked' : '' }}>
                                                        <label class="custom-control-label" for="contac_info_no">no</label>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    
                                    <div class="form-group">
                                        <label>Assigned To : {{ $assigned_to }}</label>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label>Case Type : {{ $userInfo->userCaseType }}</label>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label>Last Login : {{ date('d-m-Y', strtotime($userInfo->lastLoginTime)) }}</label>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label>Device Name : {{ $userInfo->device_name }}</label>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label>Build Version : {{ $userInfo->build_version }}</label>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label>Login With : {{ !empty($userInfo->login_with) ? ucfirst($userInfo->login_with)  :  'N/A' }}</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    @endforeach
                @else
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-9">
                                <div class="row">
                                    <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                                            <div class="form-group">
                                                <label for="f_name">First Name: <span style="color:red">*</span></label>
                                                <input
                                                    id="f_name"
                                                    class="form-control"
                                                    type="text"
                                                    name="f_name"
                                                    placeholder="First Name"  value="{{ !empty($userInfo->name) ? $userInfo->name : '' }}">
                                            </div>
                                            <div class="form-group">
                                            <label for="l_name">Last Name: <span style="color:red">*</span></label>
                                                <input
                                                    id="l_name"
                                                    class="form-control"
                                                    type="text"
                                                    name="l_name"
                                                    placeholder="Last Name" value="{{ !empty($userInfo->surname) ? $userInfo->surname : '' }}">
                                            </div>
                                            <div class="form-group">
                                            <label for="birthDay">D.O.B.: <span style="color:red">*</span></label>
                                                <input
                                                    type="text"
                                                    id="birthDay"
                                                    class="form-control datepicker"
                                                    name="birthDay"
                                                    placeholder="D.O.B." value="">
                                            </div>
                                            <div class="form-group">
                                            <label for="email">Email: <span style="color:red">*</span></label>
                                                <input
                                                    id="email"
                                                    class="form-control"
                                                    type="email"
                                                    name="email"
                                                    placeholder="Email" value="{{ !empty($userInfo->email) ? $userInfo->email : '' }}">
                                            </div>
                                            <div class="form-group">
                                            <label for="houseNumber">House No.:</label>
                                                <input
                                                    id="houseNumber"
                                                    class="form-control"
                                                    type="text"
                                                    name="houseNumber"
                                                    placeholder="House No." value="">
                                            </div>
                                            <div class="form-group">
                                            <label for="address">Address:</label>
                                                <input
                                                    id="address"
                                                    class="form-control"
                                                    type="text"
                                                    name="address"
                                                    placeholder="Address" value="">
                                            </div>
                                            <div class="form-group">
                                            <label for="country">Country: <span style="color:red">*</span></label>
                                            <select class="form-control" id="country" name="country">
                                               
                                                <option>Select option</option>
                                                @foreach ($country as $key => $value)
                                                    <option value="{{ $value->name }}">{{ $value->display_name }}</option>
                                                @endforeach
                                            </select>   
                                            {{-- <input
                                                    id="country"
                                                    class="form-control"
                                                    type="text"
                                                    name="country"
                                                    placeholder="Country"
                                                     value=""> --}}
                                            </div>
                                            <div class="form-group">
                                            <label for="postCode">Postcode:</label>
                                                <input
                                                    id="postCode"
                                                    class="form-control"
                                                    type="number"
                                                    name="postCode"
                                                    placeholder="Postcode" value="">
                                            </div>
                                            <div class="form-group">
                                                <label for="mobile">Mobile: <span style="color:red">*</span></label>
                                                <input
                                                    id="mobile"
                                                    class="form-control"
                                                    type="text"
                                                    name="mobile"
                                                    placeholder="Mobile" value="{{ !empty($userInfo->tel) ? $userInfo->tel : '' }}">
                                            </div>
                                    
                                    </div>
                                    <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                                        {{-- <form action="#"> --}}
                                            <div class="form-group">
                                            <label for="EmpStatus">Employment: <span style="color:red">*</span></label>
                                           
                                            <select name="EmpStatus" id="EmpStatus" class="form-control">
                                                    <option>Select option</option>
                                               
                                                @foreach($getEmpStatus as $key => $value)
                                                    <option value="{{ $value->name }}">{{ $value->display_name }}</option>
                                                @endforeach
                                            </select>
                                                
                                            </div>
                                            <div class="form-group">
                                            <label for="rentOrOwnHome">Living Arrangement: <span style="color:red">*</span></label>
                                            <select id="rentOrOwnHome" name="rentOrOwnHome" class="form-control">
                                                @if(!empty($result->rentOrOwnHome) && isset($result->rentOrOwnHome))
                                                        <option>{{ $result->rentOrOwnHome }}</option>
                                                    @else 
                                                        <option>Select option</option>
                                                    @endif
                                                  @foreach($living_arrangment as $key => $value)
                                                    <option>{{ $value }}</option>
                                                  @endforeach
                                            </select>    
                                            
                                            </div>
                                            <div class="form-group">
                                            <label for="haveCar">Car:</label>
                                                <input id="haveCar" class="form-control" type="text" name="haveCar" placeholder="Car:" value="">
                                            </div>
                                            <div class="form-group">
                                            <label for="isFinanced">Is Financed:</label>
                                                <input
                                                    id="isFinanced"
                                                    class="form-control"
                                                    type="text"
                                                    name="isFinanced"
                                                    placeholder="Is Financed:" value="">
                                            </div>
                                            <div class="form-group">
                                            <label for="havePets">Pet:</label>
                                                <input id="havePets" class="form-control" type="text" name="havePets" placeholder="Pet:" value="">
                                            </div>
                                            <div class="form-group">
                                            <label for="child14To18">Childern 14-18:</label>
                                                <input
                                                    id="child14To18"
                                                    class="form-control"
                                                    type="text"
                                                    name="child14To18"
                                                    placeholder="Childern 14-18:" value="">
                                            </div>
                                            <div class="form-group">
                                            <label for="childUnder14">Childern under 14:</label>
                                                <input
                                                    id="childUnder14"
                                                    class="form-control"
                                                    type="text"
                                                    name="childUnder14"
                                                    placeholder="Childern under 14:" value="">
                                            </div>
                                            <div class="form-group">
                                            <label for="Is_this_for_you_alone_or_you_and_partner">Single / Joint Solution:</label>
                                            <select class="form-control" id="Is_this_for_you_alone_or_you_and_partner" name="Is_this_for_you_alone_or_you_and_partner">
                                                @if(!empty($result->is_this_for_you_alone_or_you_and_partner) && isset($result->is_this_for_you_alone_or_you_and_partner))
                                                        <option>{{ $result->is_this_for_you_alone_or_you_and_partner }}</option>
                                                    @else 
                                                        <option>Select option</option>
                                                    @endif
                                                @foreach ($singlejoin as $key => $value)
                                                    <option>{{ $value }}</option>
                                                @endforeach
                                            </select>    
                                           
                                            </div>
                                            <div class="form-group">
                                                <label for="where_did_you_hear_about_us">Where Did You Hear About Us?</label>
                                                 <select class="form-control" id="where_did_you_hear_about_us" name="where_did_you_hear_about_us">
                                                   
                                                                <option>Select option</option>
                                                        @foreach ($aboutUs as $key => $value)
                                                            <option value="{{ $value->name }}">{{ $value->display_name }}</option>
                                                        @endforeach
                                                </select> 
                                                
                                            </div>
                                        {{--   </form> --}}
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <p style="font-size: 14px;color: #00b0ff;" class="mt-2 mb-0">
                                    Accepted T & C:
                                </p>
                                <table class="table mb-0">
                                    <tbody>
                                        <tr>
                                            <td class="text-left pl-0">
                                                <div class="custom-control custom-radio custom-control-inline">
                                                    <input type="radio" id="modal_yes" name="accepted_tearms_and_conditions_radio" class="custom-control-input" value="yes">
                                                    <label class="custom-control-label" for="modal_yes">yes</label>
                                                </div>
                                                <div class="custom-control custom-radio custom-control-inline">
                                                    <input type="radio" id="model_no" name="accepted_tearms_and_conditions_radio" class="custom-control-input" value="no">
                                                    <label class="custom-control-label" for="model_no">no</label>
                                                </div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                                <p style="font-size: 14px;color: #00b0ff;" class="mt-2 mb-0">
                                    Accepted Contact Information:
                                </p>
                                <table class="table mb-0">
                                    <tbody>
                                        <tr>
                                            <td class="text-left pl-0">
                                                <div class="custom-control custom-radio custom-control-inline">
                                                    <input
                                                        type="radio"
                                                        id="contac_info_yes"
                                                        name="contact_info_radio"
                                                        class="custom-control-input"
                                                        value="yes" {{ ($userInfo->is_contact=='yes'
                                                        ) ? 'checked' : '' }}>
                                                    <label class="custom-control-label"  for="contac_info_yes">yes</label>
                                                </div>
                                                <div class="custom-control custom-radio custom-control-inline">
                                                    <input
                                                        type="radio"
                                                        id="contac_info_no"
                                                        name="contact_info_radio"
                                                        class="custom-control-input"
                                                        value="no" {{ ($userInfo->is_contact=='no') ? 'checked' : '' }}>
                                                    <label class="custom-control-label" for="contac_info_no">no</label>
                                                </div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                                
                                <div class="form-group">
                                    <label>Assigned To : {{ $assigned_to }}</label>
                                </div>
                                
                                <div class="form-group">
                                    <label>Case Type : {{ $userInfo->userCaseType }}</label>
                                </div>
                                
                                <div class="form-group">
                                    <label>Last Login : {{ date('d-m-Y', strtotime($userInfo->lastLoginTime)) }}</label>
                                </div>
                                
                                <div class="form-group">
                                    <label>Device Name : {{ $userInfo->device_name }}</label>
                                </div>
                                
                                <div class="form-group">
                                    <label>Build Version : {{ $userInfo->build_version }}</label>
                                </div>
                                
                                <div class="form-group">
                                    <label>Login With : {{ !empty($userInfo->login_with) ? ucfirst($userInfo->login_with)  :  'N/A' }}</label>
                                </div>
                            </div>
                        </div>
                    </div>
                @endif
                <div class="modal-body">
                </div>
                <div class="modal-footer mb-5">
                    {{-- <a href="javascipt:void(0)" class="btn btn-outline-info float-right btn-large" data-dismiss="modal" id="update">Update</a> --}}
                    <input type="submit" name="submit" value="Update" class="btn btn-outline-info float-right btn-large" data-dismiss="modal" id="update">
                </div>
                {{-- </form> --}}
            </div>
    </div>
</div>
<script type="text/javascript">
$(document).ready(function(){
    
    $( ".datepicker" ).datepicker(
        {
    changeMonth: true,
    changeYear: true,
    dateFormat: 'mm/dd/yy',
    yearRange: '1950:2040', 
    beforeShow: function (input, inst) {
        var rect = input.getBoundingClientRect();
        setTimeout(function () {
            inst.dpDiv.css({ top: rect.top + 40, left: rect.left + 0 });
        }, 0);
    }});
});
</script>


<script>
$(document).on('click', '#update', function(e){
    e.preventDefault();

    var userId = $('#userId').val();
    var f_name = $('#f_name').val();
    var l_name = $('#l_name').val();
    var birthDay = $('#birthDay').val();
    var email = $('#email').val();
    var houseNumber = $('#houseNumber').val();
    var address = $('#address').val();
    var country = $('#country').val();
    var postCode = $('#postCode').val();
    var EmpStatus = $('#EmpStatus').val();
    var rentOrOwnHome = $('#rentOrOwnHome').val();
    var haveCar = $('#haveCar').val();
    var isFinanced = $('#isFinanced').val();
    var havePets = $('#havePets').val();
    var child14To18 = $('#child14To18').val();
    var childUnder14 = $('#childUnder14').val();
    var mobile = $('#mobile').val();
    var Is_this_for_you_alone_or_you_and_partner = $('#Is_this_for_you_alone_or_you_and_partner').val();
    var where_did_you_hear_about_us = $('#where_did_you_hear_about_us').val();
    var contact_info_radio = $('input[name="contact_info_radio"]:checked').val();
    var accepted_tearms_and_conditions_radio = $('input[name="accepted_tearms_and_conditions_radio"]:checked').val();

    //console.log('userId => ' + userId + ' f_name => '+ f_name +' l_name => '+ l_name +' birthDay => '+ birthDay +' email => '+ email +' houseNumber => '+ houseNumber +' address => '+ address +' country => '+ country +' postCode => '+ postCode +' EmpStatus => '+ EmpStatus +' rentOrOwnHome => '+ rentOrOwnHome +' haveCar => '+ haveCar +' isFinanced => '+ isFinanced +' havePets => '+ havePets +' child14To18 => '+ child14To18 +' childUnder14 => '+ childUnder14 + ' Is_this_for_you_alone_or_you_and_partner => ' +Is_this_for_you_alone_or_you_and_partner);

    $.ajax({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        url:'{{ route('user.update_sigunup_question') }}',
        method:'POST',
        dataType:'json',
        data:{
            "userId" : userId,
            "f_name" : f_name,
            "l_name" : l_name,
            "birthDay" : birthDay,
            "email" : email,
            "houseNumber" : houseNumber,
            "address" : address,
            "country" : country,
            "postCode" : postCode,
            "EmpStatus" : EmpStatus,
            "rentOrOwnHome" : rentOrOwnHome,
            "haveCar" : haveCar,
            "isFinanced" : isFinanced,
            "havePets" : havePets,
            "child14To18" : child14To18,
            "childUnder14" : childUnder14,
            "mobile" : mobile,
            "Is_this_for_you_alone_or_you_and_partner" : Is_this_for_you_alone_or_you_and_partner,
            "where_did_you_hear_about_us" : where_did_you_hear_about_us,
            "contact_info_radio" : contact_info_radio,
            "accepted_tearms_and_conditions_radio" : accepted_tearms_and_conditions_radio
        },
        success:function(data)
        {
            var messageIcon = 'error';
            if (data == 'RequiredFirstName') {
                var message = 'First Name is required';
            } else if (data == 'RequiredSurName') {
                var message = 'Last Name is required';
            } else if (data == 'RequiredMobile') {
                var message = 'Mobile Number is required';
            } else if (data == 'RequiredEmail') {
                var message = 'Email is required';
            } else if (data == 'RequiredBirthdate') {
                var message = 'Birthdate is required';
            } else if (data == 'RequiredEmployment') {
                var message = 'Employment is required';
            } else if (data == 'RequiredLivingArrangement') {
                var message = 'Livinng Arrangement is required';
            } else if (data == 'RequiredCountry') {
                var message = 'Country is required';
            } else if (data == 'success') {
                var message = 'Data Save Successfully';
                var messageIcon = 'success';
            } else {
                var message = 'something wrong please try again';
            }
            swal(message, {
              icon: messageIcon,
            });
        }
    });
});
</script>

