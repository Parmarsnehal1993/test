
 <main class="main-content dmp-advisor">
                <!-- header -->
                <div class="row">
                    <div class="col-12 col-sm-12 col-md-9 col-lg-9 col-xl-9">
                        <div class="row mt--100">
                            <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6  p-0">
                                <div class="main-title">
                                    <h1 class="font-h1">
                                        @php $loginUserData = Auth::user();
                                        unset($loginUserData->password);
                                        $loginUser = $loginUserData;
                                        @endphp
                                        
                                            <strong>{{ $loginUser->name }}'s Workflow</strong>
                                    </h1>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- / header -->
                <section class="card-section">
                    <!-- case view -->
                    <div class="row">
                        <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                            <div class="row ml--30 mr-0">
                                <div class="col-12 col-sm-12 col-md-3 col-lg-3 col-xl-3">
                                    <div class="card height-auto">
                                        <div class="card-title mb-0">
                                            Submitted
                                            
                                        </div>
                                        <div class="card-body height-auto">
                                        <a href="javascript:void(0)" class="statistics columnAjax d-block" data-type="submitted">
                                                <h1 class="text-center height-auto line-height-auto mb-4 mt-4">{{ (isset($allCasesCount['totalSubmittedCount']) && !empty($allCasesCount['totalSubmittedCount'])) ? $allCasesCount['totalSubmittedCount'] : 0 }}</h1>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 col-sm-12 col-md-3 col-lg-3 col-xl-3">
                                    <div class="card height-auto">
                                        <div class="card-title mb-0">
                                            Cancelled
                                        </div>
                                        <div class="card-body height-auto">
                                            {{-- <h1 class="text-center height-auto line-height-auto">80</h1> --}}
                                            <a href="javascript:void(0)" class="statistics columnAjax d-block text-center" data-type="cancelled">
                                                    <h1 class="text-center text-danger height-auto line-height-auto mb-4 mt-4">{{ (isset($allCasesCount['totalCancelledCount']) && !empty($allCasesCount['totalCancelledCount'])) ? $allCasesCount['totalCancelledCount'] : 0 }}</h1>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="card height-auto">
                                        <div class="card-title mb-0">
                                            Failed
                                        </div>
                                        <div class="card-body height-auto">
                                            <a href="javascript:void(0)" class="statistics columnAjax d-block" data-type="failed">
                                                <h1 class="text-center text-danger height-auto line-height-auto mb-4 mt-4">{{ (isset($allCasesCount['totalFailedCount']) && !empty($allCasesCount['totalFailedCount'])) ? $allCasesCount['totalFailedCount'] : 0 }}</h1>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                

                        <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                            <div class="card" style="margin-left: -15px;margin-right: 10px;">
                                <div class="row m-0 mr-0">
                                    <div class="col-12 col-sm-6 col-md-8 col-lg-8 col-xl-8 br-primary">
                                    <table class="table text-primary">
                                                <tbody>
                                                    <tr>
                                                        <td>case sent</td>
                                                        <td>{{$monthlyCases}}</td>
                                                    </tr>
                                                    <tr>
                                                        <td>DMP sent</td>
                                                        <td>{{$totalAgentDrafter}}</td>
                                                    </tr>
                                                    <tr>
                                                        <td>IVA sent</td>
                                                        <td>{{ $totalIvaSent }}</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        <div class="card-title">
                                            <?php  echo date('F'); ?> Top 3
                                        </div>
                                        <div class="card-body">
                                            <div class="table-responsive">
                                                <table class="table search-table text-center awaiating-table">
                                                    <thead>
                                                        <tr>
                                                            <th>POS</th>
                                                            <th>Name</th>
                                                            <th>DMP</th>
                                                            <th>IVA</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <td>1</td>
                                                            <td>Dave</td>
                                                            <td>6</td>
                                                            <td>6</td>
                                                        </tr>
                                                        <tr>
                                                            <td>2</td>
                                                            <td>Becky</td>
                                                            <td>4</td>
                                                            <td>4</td>
                                                        </tr>
                                                        <tr>
                                                            <td>3</td>
                                                            <td>Tim</td>
                                                            <td>3</td>
                                                            <td>3</td>
                                                        </tr>
                                                        <tr>
                                                            <td>4</td>
                                                            <td>Tim</td>
                                                            <td>3</td>
                                                            <td>3</td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12 col-sm-6 col-md-4 col-lg-4 col-xl-4">
                                        <div class="card-title">
                                            2019 Top 10
                                        </div>
                                        <div class="card-body">
                                            <table class="table text-primary">
                                                <tr>
                                                    <td>1)Name</td>
                                                </tr>
                                                <tr>
                                                    <td>2)Name</td>
                                                </tr>
                                                <tr>
                                                    <td>3)Name</td>
                                                </tr>
                                                <tr>
                                                    <td>4)Name</td>
                                                </tr>
                                                <tr>
                                                    <td>5)Name</td>
                                                </tr>
                                                <tr>
                                                    <td>6)Name</td>
                                                </tr>
                                                <tr>
                                                    <td>7)Name</td>
                                                </tr>
                                                <tr>
                                                    <td>8)Name</td>
                                                </tr>
                                                <tr>
                                                    <td>9)Name</td>
                                                </tr>
                                                <tr>
                                                    <td>10)Name</td>
                                                </tr>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- // Right Column -->
                    </div>
                    <!-- // proceess -->
                </section>
            </main>