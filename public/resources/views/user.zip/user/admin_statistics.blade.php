@php
    $loginUserData = Auth::user();
    unset($loginUserData->password);

    $loginUser = $loginUserData;
@endphp

<main class="main-content admin-dashboard pt-0">
                <div class="row">
                    <div class="col-12 col-sm-12 col-md-9 col-lg-9 col-xl-9">
                        <div class="row mt--70 mb-3">
                            <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-12  p-0">
                                <div class="main-title">
                                    <h1 class="font-h1">
                                        <strong>{{ $loginUser->name }} Workflow</strong>
                                    </h1>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- / header -->
                <section class="card-section">
                    <!-- case view -->
                    <div class="row">
                        <div class="col-12 col-sm-12 col-md-12 col-lg-8 col-xl-7">
                            <div class="row ml--30 mr-0">
                                <div class="col-6 col-lg-6 col-md-6 col-sm-12 col-xl-6">
                                    <div class="card height-auto">
                                            @php
                                            $data_new = getRecordNew();
                                            @endphp
                                        <div class="card-title d-flex justify-content-between mb-0 align-items-center">
                                            <h3>Review/completed</h3>
                                            <a href="javascript:void(0)" class="statistics columnAjax d-block" data-type="NEW">
                                            <div class="d-flex justify-content-between ct-space">
                                                <h1>{{ $data_new ? $data_new : 0 }}</h1>
                                                <h1></h1>
                                            </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-6 col-lg-6 col-md-6 col-sm-12 col-xl-6">
                                    <div class="card height-auto">
                                        <div class="card-title d-flex justify-content-between mb-0 align-items-center">
                                            <h3> DMP Draft</h3>
                                            <a href="javascript:void(0)" class="statistics columnAjax d-block" data-type="dmp draft">
                                            <div class="d-flex justify-content-between ct-space">    
                                                <h1>{{(isset($columnCount['dmp draft']) && !empty($columnCount['dmp draft'])) ? $columnCount['dmp draft'] : 0 }}</h1>
                                                <h1></h1>
                                            </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row ml--30 mr-0">
                                <!--<div class="col-6 col-lg-6 col-md-6 col-sm-12 col-xl-6">-->
                                <!--    <div class="card height-auto">-->
                                <!--        <div class="card-title d-flex justify-content-between mb-0 align-items-center">-->
                                <!--            <h3>Quick Review</h3>-->
                                <!--            <a href="javascript:void(0)" class="statistics columnAjax d-block" data-type="QUICK REVIEW">-->
                                <!--            <div class="d-flex justify-content-between ct-space">-->
                                <!--                <h1></h1>-->
                                <!--                <h1></h1>-->
                                <!--            </a>-->
                                <!--            </div>-->
                                <!--        </div>-->
                                <!--    </div>-->
                                <!--</div>-->
                                <div class="col-6 col-lg-6 col-md-6 col-sm-12 col-xl-6">
                                    <div class="card height-auto">
                                        <div class="card-title d-flex justify-content-between mb-0 align-items-center">
                                            <h3>Sent To DMP</h3>
                                            <a href="javascript:void(0)" class="statistics columnAjax d-block" data-type="Sent to DMP">
                                            <div class="d-flex justify-content-between ct-space">
                                                <h1>{{ (isset($allCasesCount['totalSendToDmpCount']) && !empty($allCasesCount['totalSendToDmpCount'])) ? $allCasesCount['totalSendToDmpCount'] : 0 }}</h1>
                                                <h1></h1>
                                            </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row ml--30 mr-0">
                                <div class="col-6 col-lg-6 col-md-6 col-sm-12 col-xl-6">
                                    <div class="card height-auto">
                                        @php
                                         $messageDay2 = messageday2();
                                        @endphp
                                        <div class="card-title d-flex justify-content-between mb-0 align-items-center">
                                            <h3>Day 2</h3>  
                                            <a href="javascript:void(0)" class="statistics columnAjax d-block" data-type="messageday2">
                                            <div class="d-flex justify-content-between ct-space">  
                                                <h1>{{ (isset($messageDay2) && !empty($messageDay2)) ? $messageDay2 : 0 }}</h1>
                                                <h1></h1>
                                            </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-6 col-lg-6 col-md-6 col-sm-12 col-xl-6">
                                    <div class="card height-auto">
                                        <div class="card-title d-flex justify-content-between mb-0 align-items-center">
                                            <h3>Paid On MOC</h3>
                                            <a href="javascript:void(0)" class="statistics columnAjax d-block" data-type="Paid on MOC">
                                            <div class="d-flex justify-content-between ct-space">
                                                <h1>{{ (isset($allCasesCount['totalPaidOnMocCount']) && !empty($allCasesCount['totalPaidOnMocCount'])) ? $allCasesCount['totalPaidOnMocCount'] : 0 }}</h1>
                                                <h1></h1>
                                            </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row ml--30 mr-0">
                                <div class="col-6 col-lg-6 col-md-6 col-sm-12 col-xl-6">
                                    <div class="card height-auto">
                                        @php
                                          $messageDay3 = messageday3();
                                        @endphp
                                        <div class="card-title d-flex justify-content-between mb-0 align-items-center">
                                            <h3>Day 3</h3>
                                            <a href="javascript:void(0)" class="statistics columnAjax d-block" data-type="messageday3">
                                            <div class="d-flex justify-content-between ct-space">
                                                <h1>{{ (isset($messageDay3) && !empty($messageDay3)) ? $messageDay3 : 0 }}</h1>
                                                <h1></h1>
                                            </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-6 col-lg-6 col-md-6 col-sm-12 col-xl-6">
                                    <div class="card height-auto">
                                        <div class="card-title d-flex justify-content-between mb-0 align-items-center">
                                            <h3>Submitted</h3>
                                            <div class="d-flex justify-content-between ct-space">
                                                <a href="javascript:void(0)" class="statistics columnAjax d-block" data-type="submitted">
                                                <h1>{{ (isset($allCasesCount['totalSubmittedCount']) && !empty($allCasesCount['totalSubmittedCount'])) ? $allCasesCount['totalSubmittedCount'] : 0 }}</h1>
                                                <h1></h1>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row ml--30 mr-0">
                                <div class="col-6 col-lg-6 col-md-6 col-sm-12 col-xl-6">
                                    <div class="card height-auto">
                                         @php
                                            $messageDay4 = messageday4();
                                        @endphp
                                        <div class="card-title d-flex justify-content-between mb-0 align-items-center">
                                            <h3>Day 4</h3>
                                            <a href="javascript:void(0)" class="statistics columnAjax d-block" data-type="messageday4">
                                            <div class="d-flex justify-content-between ct-space">
                                                <h1>{{ (isset($messageDay4) && !empty($messageDay4)) ? $messageDay4 : 0 }}</h1>
                                                <h1></h1>
                                            </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-6 col-lg-6 col-md-6 col-sm-12 col-xl-6">
                                    <div class="card height-auto">
                                        <div class="card-title d-flex justify-content-between mb-0 align-items-center">
                                            <h3>cancelled</h3>
                                            <a href="javascript:void(0)" class="statistics columnAjax d-block" data-type="cancelled">
                                            <div class="d-flex justify-content-between ct-space">
                                                <h1>{{ (isset($allCasesCount['totalCancelledCount']) && !empty($allCasesCount['totalCancelledCount'])) ? $allCasesCount['totalCancelledCount'] : 0 }}</h1>
                                                <h1></h1>
                                            </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row ml--30 mr-0">
                                <div class="col-6 col-lg-6 col-md-6 col-sm-12 col-xl-6">
                                    <div class="card height-auto">
                                        <div class="card-title d-flex justify-content-between mb-0 align-items-center">
                                           <h3>In Process</h3>
                                            @php
                                                //$getCountInProcess = getCountIn('In Process');
                                                $totalInProcessCount = (isset($allCasesCount['totalInProcessCount']) && !empty($allCasesCount['totalInProcessCount'])) ? $allCasesCount['totalInProcessCount'] : 0;
                                            
                                                $totalInProcessOverdueCount = getOverdueCount('In Process_overdue');
                                                
                                            @endphp
                                                <a href="javascript:void(0)" class="statistics columnAjax d-flex justify-content-between ct-space" data-type="In Process">
                                                <h1>{{ $totalInProcessCount }}</h1>

                                                <h1 class="text-danger">{{ $totalInProcessOverdueCount }}</h1>
                                                </a>
                                               
                                        </div>
                                    </div>
                                </div>
                                <div class="col-6 col-lg-6 col-md-6 col-sm-12 col-xl-6">
                                    <div class="card height-auto">
                                        <div class="card-title d-flex justify-content-between mb-0 align-items-center">
                                            <h3>Invoice</h3>
                                            @php 
                                                $invoice = getCountFunc('invoice');
                                            @endphp
                                            <div class="d-flex justify-content-between ct-space">
                                                <a href="javascript:void(0)" class="statistics columnAjax d-block" data-type="invoice">
                                                    <h1>{{ (isset($invoice) && !empty($invoice)) ? $invoice : 0 }}</h1>
                                                </a>
                                                <h1></h1>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row ml--30 mr-0">
                                <div class="col-6 col-lg-6 col-md-6 col-sm-12 col-xl-6">
                                    <div class="card height-auto">
                                        <div class="card-title d-flex justify-content-between mb-0 align-items-center">
                                            <h3>Awaiting Docs</h3>
                                            @php
                                                //$getCountAwaitingDocs = getCountIn('Awaiting Docs');
                                                $totalAwaitingDocsCount = (isset($allCasesCount['totalAwaitingDocsCount']) && !empty($allCasesCount['totalAwaitingDocsCount'])) ? $allCasesCount['totalAwaitingDocsCount'] : 0;
                                                //$dataawaiting = awaintingDocsOverdue();
                                                $totalAwaitingDocsOverdueCount = getOverdueCount('Awaiting Docs_overdue');
                                            @endphp 
                                            <a href="javascript:void(0)" class="statistics columnAjax d-flex justify-content-between ct-space" data-type="Awaiting Docs">
                                                <h1>{{ $totalAwaitingDocsCount }}</h1>
                                                <h1 class="text-danger">{{ $totalAwaitingDocsOverdueCount }}</h1>
                                            </a> 
                                        </div>
                                    </div>
                                </div>
                                <div class="col-6 col-lg-6 col-md-6 col-sm-12 col-xl-6">
                                    <div class="card height-auto">
                                        <div class="card-title d-flex justify-content-between mb-0 align-items-center">
                                            <h3>Failed Compliance</h3>
                                             @php 
                                                $data = getCountFunc('Failed Compliance');
                                            @endphp
                                            <div class="d-flex justify-content-between ct-space">
                                                <a href="javascript:void(0)" class="statistics columnAjax d-block text-center" data-type="Failed Compliance">
                                                    <h1 class="text-danger">{{ $data ? $data : 0 }}</h1>
                                                </a>
                                                <h1></h1>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row ml--30 mr-0">
                                <div class="col-6 col-lg-6 col-md-6 col-sm-12 col-xl-6">
                                    <div class="card height-auto">
                                        <div class="card-title d-flex justify-content-between mb-0 align-items-center">
                                            <h3>IVA Draft</h3>
                                            <div class="d-flex justify-content-between ct-space">
                                                <a href="javascript:void(0)" class="statistics columnAjax d-flex justify-content-between ct-space" data-type="iva draft">
                                                <h1>{{ (isset($allCasesCount['totalIvaDraftCount']) && !empty($allCasesCount['totalIvaDraftCount'])) ? $allCasesCount['totalIvaDraftCount'] : 0 }}</h1>
                                                </a>
                                                <a href="javascript:void(0)" class="statistics columnAjax d-block text-center" data-type="iva draft overdue">
                                                    @php
                                                        $data = getOverdueCount('iva draft');
                                                    @endphp
                                                    <h1 class="text-danger">{{ $data ? $data : 0 }}</h1>
                                                </a>
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-6 col-lg-6 col-md-6 col-sm-12 col-xl-6">
                                    <div class="card height-auto">
                                        <div class="card-title d-flex justify-content-between mb-0 align-items-center">
                                            <h3>Fixed Compliance</h3>
                                             @php 
                                                $data = getCountFunc('Fixed Compliance');
                                            @endphp
                                            <div class="d-flex justify-content-between ct-space">
                                                <a href="javascript:void(0)" class="statistics columnAjax d-block text-center" data-type="Fixed Compliance">
                                                    <h1 class="text-danger">{{ $data ? $data : 0 }}</h1>
                                                </a>
                                                <h1></h1>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row ml--30 mr-0">
                                <div class="col-6 col-lg-6 col-md-6 col-sm-12 col-xl-6">
                                    <div class="card height-auto">
                                        <div class="card-title d-flex justify-content-between mb-0 align-items-center">
                                            <h3>Sent To IP</h3>  
                                            @php
                                              $data = getOverdueCount('SENT TO IP');
                                            @endphp
                                            <a href="javascript:void(0)" class="statistics columnAjax d-flex justify-content-between ct-space" data-type="SENT TO IP">
                                                <h1>{{ (isset($allCasesCount['totalSentToIpCount']) && !empty($allCasesCount['totalSentToIpCount'])) ? $allCasesCount['totalSentToIpCount'] : 0 }}</h1>
                                                <a href="javascript:void(0)" class="statistics columnAjax d-block text-center" data-type="SENT TO IP overdue">
                                                    <h1 class="text-danger">{{ $data ? $data : 0}}</h1></a>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <!-- <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                                    <div class="card height-auto">
                                        <div class="card-title d-flex justify-content-between mb-0 align-items-center">
                                            DMP Draft
                                            <div class="d-flex justify-content-between ct-space">
                                                <h1>50</h1>
                                                <h1></h1>
                                            </div>
                                        </div>
                                    </div>
                                </div> -->
                            </div>
                        </div>
                        <!-- Right Column -->
                        <div class="col-12 col-sm-12 col-md-12 col-lg-4 col-xl-5 p-md-0">
                            <div class="card primary-radius">
                                <div class="card-title"> 
                                    <h2><?php  echo date('F'); ?>Overview</h2>
                                </div>
                                <div class="row">
                                    <div class="col-12 col-sm-10 col-md-10 col-xl-10">
                                        <div class="card-body">
                                            <table class="table text-primary td-p-0">
                                                <tbody>
                                                    <tr>
                                                        <td>case sent</td>
                                                        <td>{{$monthlyCases}}</td>
                                                    </tr>
                                                    <tr>
                                                        <td>DMP sent</td>
                                                        <td>{{$totalAgentDrafter}}</td>
                                                    </tr>
                                                    <tr>
                                                        <td>IVA sent</td>
                                                        <td>{{ $totalIvaSent }}</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- // Right Column -->
                    </div>
                    <!--/ case view -->
                </section>
</main>