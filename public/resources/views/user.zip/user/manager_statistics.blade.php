 <main class="main-content dmp-advisor">
                <!-- header -->
                <div class="row">
                    <div class="col-12 col-sm-12 col-md-9 col-lg-9 col-xl-9">
                        <div class="row mt--100">
                            <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6  p-0">
                                <div class="main-title">
                                    <h1 class="font-h1">
                                        @php $loginUserData = Auth::user();
                                        unset($loginUserData->password);
                                        $loginUser = $loginUserData;
                                        @endphp
                                        @if($loginUser->user_type == 8)
                                            <strong>{{ $loginUser->name }}'s Workflow</strong>
                                        @endif
                                    </h1>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- / header -->
               <section class="card-section">
                    <!-- case view -->
                    <div class="row">
                        <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                            <div class="row ml--30 mr-0">
                                <div class="col-12 col-sm-12 col-md-3 col-lg-3 col-xl-3">
                                    <div class="card height-auto">
                                        <div class="card-title mb-0">
                                            Review/Completed
                                        </div>
                                        <div class="card-body height-auto">
                                            @php
                                            //$data = ReviewCompletedData();
                                            $totalReviewCount = (isset($allCasesCount['totalReviewCount']) && !empty($allCasesCount['totalReviewCount'])) ? $allCasesCount['totalReviewCount'] : 0;
                                            @endphp
                                            <a
                                                href="javascript:void(0)"
                                                class="statistics columnAjax d-block"
                                                data-type="NEW"> 
                                                <h1 class="text-center">{{ $totalReviewCount }}</h1>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 col-sm-12 col-md-3 col-lg-3 col-xl-3">
                                    <div class="card height-auto">
                                        <div class="card-title mb-0">
                                            Day 2
                                        </div>
                                        <div class="card-body height-auto">
                                            {{-- <h1 class="text-center height-auto line-height-auto">80</h1> --}}
                                            <a href="javascript:void(0)" class="statistics columnAjax d-block text-center" data-type="messageday1">
                                                    <h1 class="text-center">
                                                       {{ (isset($allCasesCount['totalMessageDay1Count']) && !empty($allCasesCount['totalMessageDay1Count'])) ? $allCasesCount['totalMessageDay1Count'] : 0 }}
                                                    </h1>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 col-sm-12 col-md-3 col-lg-3 col-xl-3">
                                    <div class="card height-auto">
                                        <div class="card-title mb-0">
                                            Day 3
                                        </div>
                                        <div class="card-body">
                                        <a href="javascript:void(0)" class="statistics columnAjax d-block text-center" data-type="messageday2">
                                                 <h1 class="text-center">
                                                     {{ (isset($allCasesCount['totalMessageDay2Count']) && !empty($allCasesCount['totalMessageDay2Count'])) ? $allCasesCount['totalMessageDay2Count'] : 0 }}
                                                 </h1>
                                         </a>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-12 col-sm-12 col-md-3 col-lg-3 col-xl-3">
                                    <div class="card height-auto">
                                        <div class="card-title mb-0">
                                            Day 4
                                        </div>
                                        <div class="card-body">
                                         <a href="javascript:void(0)" class="statistics columnAjax d-block text-center" data-type="messageday3">
                                                <h1 class="text-center">
                                                    {{ (isset($allCasesCount['totalMessageDay3Count']) && !empty($allCasesCount['totalMessageDay3Count'])) ? $allCasesCount['totalMessageDay3Count'] : 0 }}
                                                </h1>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row  ml--30 mr-0">
                                <div class="col-12 col-sm-12 col-md-3 col-lg-3 col-xl-3">
                                    <div class="row">
                                        <div class="col-6">
                                            <div class="card section-height-auto height-auto">
                                                <div class="card-title text-center">
                                                    new
                                                </div>
                                                <div class="card-body text-center">
                                                    <a
                                                        href="javascript:void(0)"
                                                        class="statistics columnAjax  d-block"
                                                        data-type="NEW">
                                                        <h1 class="text-center height-auto line-height-auto">
                                                            {{ (isset($allCasesCount['totalNewCount']) && !empty($allCasesCount['totalNewCount'])) ? $allCasesCount['totalNewCount'] : 0 }}
                                                        </h1>
                                                    </a>
                                                    <button class="download btn btn-outline-info" data-toggle="modal" data-target="#download_modal" data-backdrop="static" data-keyboard="false">
                                                        Download
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div class="card section-height-auto height-auto">
                                                <div class="card-title text-center">
                                                    ND 1
                                                </div>
                                                <div class="card-body text-center">
                                                    <a
                                                        href="javascript:void(0)"
                                                        class="statistics columnAjax d-block"
                                                        data-type="ND1">
                                                        <h1 class="text-center height-auto line-height-auto">
                                                            {{ (isset($allCasesCount['totalND1Count']) && !empty($allCasesCount['totalND1Count'])) ? $allCasesCount['totalND1Count'] : 0 }}
                                                        </h1>
                                                    </a>
                                                    <button class="download btn btn-outline-info" data-toggle="modal" data-target="#download_modal" data-backdrop="static" data-keyboard="false">
                                                        Download
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 col-sm-12 col-md-3 col-lg-3 col-xl-3">
                                    <div class="row">
                                        <div class="col-6">
                                            <div class="card section-height-auto height-auto">
                                                <div class="card-title text-center">
                                                    ND 2
                                                </div>
                                                <div class="card-body text-center">
                                                    <a
                                                        href="javascript:void(0)"
                                                        class="statistics columnAjax d-block"
                                                        data-type="ND2">
                                                        <h1 class="text-center height-auto line-height-auto">
                                                            {{ (isset($allCasesCount['totalND2Count']) && !empty($allCasesCount['totalND2Count'])) ? $allCasesCount['totalND2Count'] : 0 }}
                                                        </h1>
                                                    </a>
                                                    <button class="download btn btn-outline-info" data-toggle="modal" data-target="#download_modal" data-backdrop="static" data-keyboard="false">
                                                        Download
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div class="card section-height-auto height-auto">
                                                <div class="card-title text-center">
                                                    ND 3
                                                </div>
                                                <div class="card-body text-center">
                                                    <a
                                                        href="javascript:void(0)"
                                                        class="statistics columnAjax d-block"
                                                        data-type="ND3">
                                                        <h1 class="text-center height-auto line-height-auto">
                                                            {{ (isset($allCasesCount['totalND3Count']) && !empty($allCasesCount['totalND3Count'])) ? $allCasesCount['totalND3Count'] : 0 }}
                                                        </h1>
                                                    </a>
                                                    <button class="download btn btn-outline-info" data-toggle="modal" data-target="#download_modal" data-backdrop="static" data-keyboard="false">
                                                        Download
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                                    <div class="row">
                                        <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                                            <div class="card section-height-auto height-auto" style="min-height: 208px !important;">
                                                <div class="card-title">
                                                    In Process
                                                </div>
                                                  <div class="card-body">
                                            <div class="row"> 
                                                <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6 text-center">
                                                    <a href="javascript:void(0)" class="statistics columnAjax d-block" data-type="In Process">
                                                        <h1>{{ (isset($allCasesCount['totalInProcessCount']) && !empty($allCasesCount['totalInProcessCount'])) ? $allCasesCount['totalInProcessCount'] : 0 }}</h1>
                                                    </a>
                                                    <p class="text-primary">
                                                        Total
                                                    </p>
                                                </div>
                                                <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6 text-center">
                                                    @php 
                                                        $data = getOverdueCount('in_process_all');
                                                        
                                                        
                                                    @endphp
                                                    <a href="javascript:void(0)" class="statistics columnAjax d-block text-center" data-type="In Process-overdue">
                                                            <h1 class="text-danger">{{ $data ? $data : 0 }}</h1>
                                                    </a>
                                                    <p class="text-danger">
                                                        overdue
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                            </div>
                                        </div>
                                        <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                                            <div class="card section-height-auto height-auto" style="min-height: 208px !important;">
                                                <div class="card-title">
                                                    Awaiting Docs 
                                                </div>
                                                 <div class="card-body">
                                            <div class="row">
                                                <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6 text-center">
                                                    <a href="javascript:void(0)" class="statistics columnAjax d-block" data-type="Awaiting Docs">
                                                            <h1>{{ (isset($allCasesCount['totalAwaitingDocsCount']) && !empty($allCasesCount['totalAwaitingDocsCount'])) ? $allCasesCount['totalAwaitingDocsCount'] : 0 }}</h1>
                                                    </a>
                                                    
                                                   <p class="text-primary">
                                                        Total
                                                    </p>
                                                  
                                                </div>
                                                <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6 text-center">
                                                     
                                                         @php 
                                                            $data = getOverdueCount('awaiting_docs_all');
                                                        @endphp
                                                   
                                                        <a href="javascript:void(0)" class="statistics columnAjax d-block text-center" data-type="Awaiting Docs-overdue">
                                                            <h1 class="text-danger">{{ $data ? $data : 0 }}</h1>
                                                        </a>
                                                        <p class="text-danger">
                                                        overdue 
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--/ case view -->
                    <!-- proceess -->
                    <div class="row">
                        <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                            <div class="row ml--30 mr-0">
                                <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                                    <div class="card section-height-auto height-auto" style="min-height: 234px !important;">
                                        <div class="card-title">
                                            DA quality
                                        </div>
                                        <div class="card-body">
                                            <div class="row">
                                                <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6 text-center">
                                                    <a
                                                        href="javascript:void(0)"
                                                        class="statistics columnAjax d-block"
                                                        data-type="da_quality">
                                                        <h1>
                                                            @php
                                                            //$data = da_quality();
                                                            $totalDaQualityCount = (isset($allCasesCount['totalDaQualityCount']) && !empty($allCasesCount['totalDaQualityCount'])) ? $allCasesCount['totalDaQualityCount'] : 0;
                                                            @endphp
                                                            {{ $totalDaQualityCount }}
                                                        </h1>
                                                    </a>
                                                    <p class="text-primary">
                                                        Total
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Right Column -->
                        <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                            <div
                                class="card min-height-auto height-auto"
                                style="margin-left: -15px;margin-right: 10px;">
                                <div class="row m-0 mr-0">
                                    <div class="col-12 col-sm-6 col-md-8 col-lg-8 col-xl-8 br-primary">
                                        <div class="card-title">
                                            <?php  echo date('F'); ?>
                                            Top 3
                                        </div>
                                        <div class="card-body">
                                             @if(isset($topMonthAgent['finalTopArr']) && !empty($topMonthAgent['finalTopArr']))
                                            <div class="table-responsive">
                                                <table class="table search-table text-left awaiating-table">
                                                    <thead>
                                                        <tr>
                                                            <th>POS</th>
                                                            <th>Name</th>
                                                            <th>DMP</th>
                                                            <th>IVA</th>
                                                             <!--<td class="pb-1 pt-1">1</td>-->
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                         @php $topCounter = 1; @endphp
                                                                        @foreach($topMonthAgent['finalTopArr'] as $topMonthAgentKey => $topMonthAgentValue)
                                                                            <tr>
                                                                                <td class="pb-1 pt-1">{{ $topCounter }}</td>
                                                                                <td class="pb-1 pt-1">{{ $topMonthAgent['userArray'][$topMonthAgentKey] }}</td>
                                                                                <td class="pb-1 pt-1">{{ isset($topMonthAgentValue['dmp']) ? $topMonthAgentValue['dmp'] : 0 }}</td>
                                                                                <td class="pb-1 pt-1">{{ isset($topMonthAgentValue['iva']) ? $topMonthAgentValue['iva'] : 0 }}</td>
                                                                            </tr>
                                                                            @php $topCounter++; @endphp
                                                                        @endforeach
                                                    </tbody>
                                                </table>
                                            </div>
                                            @endif
                                        </div>
                                    </div>
                                    <div class="col-12 col-sm-6 col-md-4 col-lg-4 col-xl-4">
                                        <div class="card-title">
                                            2019 Top 10
                                        </div>
                                        <div class="card-body">
                                            <table class="table awaiating-table td-no-p">
                                                <tbody>
                                                    <tr>
                                                        <td>Cases Sent:</td>
                                                        <td>1</td>
                                                    </tr>
                                                    <tr>
                                                        <td>DMP Sent:</td>
                                                        <td>0</td>
                                                    </tr>
                                                    <tr>
                                                        <td>IVA Sent:</td>
                                                        <td>00</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- // Right Column -->
                    </div>
                    <!-- // proceess -->
                </section>
            </main>
            <div id="download_modal" class="modal fade entercase"
                tabindex="-1"
                role="dialog"
                aria-labelledby="my-modal-title"
                aria-hidden="true">
                <div
                    class="modal-dialog modal-dialog-centered modal-lg"
                    role="document"
                    style="height: auto;min-height: auto !important;">
                    <div class="modal-content card card-secondary">
                        <div class="modal-header">
                            <h1 class="modal-title">Are You Sure?</h1>
                        </div>
                        <div class="modal-body pb-0">
                        <p class="mb-0" id="message"></p>
                        </div>
                        <div class="modal-footer justify-content-start pb-0">
                            <div class="buttons width-100 justify-content-between">
                            <a id="download_report" class="case_change btn btn-outline-primary" data-case_status="" data-dismiss="modal">Yes</a>
                                <a class="btn btn-outline-primary" data-dismiss="modal" id="modal_hide">back</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

<script type="text/javascript">

$(document).on('click','.download',function()
{
        var case_status_name = $(this).prev().attr('data-type');
        
            var case_available = $(this).prev().text();
            
            if(case_available > 0) 
            {
        
                if(case_status_name == 'NEW')
                {
                    $('.no_data').text('Are You Sure?');
                    var message = 'All'+' '+case_status_name+' '+'will be moved into ND1';
                } 
                else if(case_status_name == 'ND1')
                {
                    $('.no_data').text('Are You Sure?');
                    var message = 'All'+' '+case_status_name+' '+'will be moved into ND2';
                }
                else if(case_status_name == 'ND2')
                {
                    $('.no_data').text('Are You Sure?');
                    var message = 'All'+' '+case_status_name+' '+'will be moved into ND3';
                }
                else if(case_status_name == 'ND3')
                {
                    $('.no_data').text('Are You Sure?');
                    var message = 'All'+' '+case_status_name+' '+'will be moved into ND4';
                }

                $('#message').text(message);
                
          window.location ='{{ URL::to('download/excel_case') }}/'+case_status_name;

    $(document).on('click','.case_change',function()
    {
            $.ajax({
            url:'{{ route('User.changeCaseStatusNd') }}',
            method:'get',
            data:{case_status:case_status_name},
            success:function(data)
            {
                var messageIcon = 'error';
                    if (data == 'success') {
                        var message = 'something wrong please try again';
                    } else {
                        var message = 'Data Save Successfully';
                        var messageIcon = 'success';
                    }
                    swal(message, {
                    icon: messageIcon,
                    });
                    location.reload();
       
            }
            
            
        });
           
    });
    
 }
 else
 {
     var message = 'No Data Available';
     
     $('.no_data').text('');

     $('#message').text(message);
 }

});


</script>