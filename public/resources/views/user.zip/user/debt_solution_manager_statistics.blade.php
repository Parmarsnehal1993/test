@php
    $loginUserData = Auth::user();
    unset($loginUserData->password);

    $loginUser = $loginUserData;

@endphp
    <!-- /sidebar end -->
    <!-- start .main-content -->
    <main class="main-content dmp-advisor pt-0">
        <!-- header -->
        <div class="row">
            <div class="col-12 col-sm-12 col-md-9 col-lg-9 col-xl-9">
                <div class="row mt--80 mb-0" style="margin-top:-50px;">
                    <div class="col-12 col-sm-12 col-md-12 col-lg-6 col-xl-12  p-0">
                        <div class="main-title">
                            <h1 class="font-h1">
                                @if($loginUser->user_type == 10)
                                <strong>{{ $loginUser->name }}'s Workflow</strong>
                                @endif
                            </h1>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- / header -->
        <section class="card-section">
            <!-- case view -->
            <!--/ case view -->
            <!-- proceess -->
            <div class="row">
                <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                    <div class="row ml--30 mr-0">
                        <div class="col-12 col-sm-12 col-md-3 col-lg-3 col-xl-3">
                            <div class="card section-height-auto height-auto">
                                <div class="card-title">
                                    DMP Draft       
                                </div>
                                <div class="card-body text-center">   
                                    <a href="javascript:void(0)" class="statistics columnAjax d-block" data-type="dmp draft"> 
                                        <h1>{{ $allCasesCount['totaldmpcount'] ? $allCasesCount['totaldmpcount'] : 0 }}</h1>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-sm-12 col-md-3 col-lg-3 col-xl-3">
                            <div class="card section-height-auto height-auto">
                                <div class="card-title">
                                    Sent to DMP Provider
                                </div>                     
                                <div class="card-body text-center">   
                                    <a href="javascript:void(0)" class="statistics columnAjax d-block" data-type="SEND TO DMP PROVIDER">
                                        <h1>{{ $allCasesCount['totalSendToDmpProviderCount'] ? $allCasesCount['totalSendToDmpProviderCount'] : 0 }}</h1>
                                    </a>
                                </div>
                            </div>
                        </div>
                         <div class="col-12 col-sm-12 col-md-3 col-lg-3 col-xl-3">
                            <!--<div class="card section-height-auto height-auto">-->
                            <!--    <div class="card-title">-->
                            <!--        DMP In Process-->
                            <!--    </div>-->
                            <!--    <div class="card-body text-center">   -->
                            <!--        <div class="row">-->
                            <!--            <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6 text-center">-->
                            <!--                <a href="javascript:void(0)" class="statistics columnAjax d-block" data-type="DMP In Process">-->
                            <!--                    <h1>  </h1>-->
                            <!--                </a>-->
                            <!--            </div>-->
                                        

                            <!--            <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6 text-center">-->
                            <!--                <a href="javascript:void(0)" class="statistics columnAjax d-block" data-type="DMP In Process overdue">-->
                            <!--                   
                            <!--                    <h1 class="text-danger">  </h1>-->
                            <!--                </a>-->
                            <!--            </div>-->
                            <!--        </div>-->
                            <!--    </div>-->
                            <!--</div>-->
                        </div>
                        <div class="col-12 col-sm-12 col-md-3 col-lg-3 col-xl-3">
                            <!--<div class="card section-height-auto height-auto">-->
                            <!--    <div class="card-title">-->
                            <!--        DMP Awaiting Docs-->
                            <!--    </div>-->
                            <!--    <div class="card-body text-center">   -->
                            <!--        <div class="row">-->
                            <!--            <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6 text-center">-->
                            <!--                <a href="javascript:void(0)" class="statistics columnAjax d-block" data-type="DMP Awaiting Docs">-->
                            <!--                    <h1></h1>-->
                            <!--                </a>-->
                            <!--            </div>-->

                            <!--            <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6 text-center">-->
                            <!--                <a href="javascript:void(0)" class="statistics columnAjax d-block" data-type="DMP Awaiting Docs overdue">-->
                                                
                                                
                            <!--                    <h1 class="text-danger"> </h1>-->
                            <!--                </a>-->
                            <!--            </div>-->
                            <!--        </div>-->
                            <!--    </div>-->
                            <!--</div>-->
                        </div>
                    </div>
                    <div class="row ml--30 mr-0">
                        <div class="col-12 col-sm-12 col-md-3 col-lg-3 col-xl-3">
                            <div class="card section-height-auto height-auto">
                                <div class="card-title">
                                    IVA Draft     
                                </div>
                                <div class="card-body text-center">   
                                    <a href="javascript:void(0)" class="statistics columnAjax d-block" data-type="iva draft">
                                        <h1>{{ $allCasesCount['ivadraftCount'] ? $allCasesCount['ivadraftCount'] : 0 }}</h1>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-sm-12 col-md-3 col-lg-3 col-xl-3">
                            <div class="card section-height-auto height-auto">
                                <div class="card-title">
                                IVA Sent to IP
                                </div>                     
                                <div class="card-body text-center">   
                                    <a href="javascript:void(0)" class="statistics columnAjax d-block" data-type="IVA SENT TO IP">
                                        <h1>{{ $allCasesCount['IVASentToIpCount'] ? $allCasesCount['IVASentToIpCount'] : 0 }}</h1>
                                    </a>
                                </div>
                            </div>
                        </div>
                         <div class="col-12 col-sm-12 col-md-3 col-lg-3 col-xl-3">
                            <!--<div class="card section-height-auto height-auto">-->
                            <!--    <div class="card-title">-->
                            <!--    IVA In Process-->
                            <!--    </div>-->
                            <!--    <div class="card-body text-center">   -->
                            <!--        <div class="row">-->
                            <!--            <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6 text-center">-->
                            <!--                <a href="javascript:void(0)" class="statistics columnAjax d-block" data-type="IVA In Process">-->
                            <!--                    <h1></h1>-->
                            <!--                </a>-->
                            <!--            </div>-->

                            <!--            <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6 text-center">-->
                            <!--                <a href="javascript:void(0)" class="statistics columnAjax d-block" data-type="IVA In Process overdue">-->
                                               
                            <!--                    <h1 class="text-danger"></h1>-->
                            <!--                </a>-->
                            <!--            </div>-->
                            <!--        </div>-->
                            <!--    </div>-->
                            <!--</div>-->
                        </div>
                        <div class="col-12 col-sm-12 col-md-3 col-lg-3 col-xl-3">
                            <!--<div class="card section-height-auto height-auto">-->
                            <!--    <div class="card-title">-->
                            <!--        IVA Awaiting Docs-->
                            <!--    </div>-->
                            <!--    <div class="card-body text-center">   -->
                            <!--        <div class="row">-->
                            <!--            <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6 text-center">-->
                            <!--                <a href="javascript:void(0)" class="statistics columnAjax d-block" data-type="IVA Awaiting Docs">-->
                            <!--                    <h1></h1>-->
                            <!--                </a>-->
                            <!--            </div>-->

                            <!--            <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6 text-center">-->
                            <!--                <a href="javascript:void(0)" class="statistics columnAjax d-block" data-type="IVA Awaiting Docs overdue">-->
                                              
                            <!--                    <h1 class="text-danger"></h1>-->
                            <!--                </a>-->
                            <!--            </div>-->
                            <!--        </div>-->
                            <!--    </div>-->
                            <!--</div>-->
                        </div>
                    </div>
                    {{-- add new row --}}
                    <div class="row ml--30 mr-0">
                        <div class="col-12 col-sm-12 col-md-3 col-lg-3 col-xl-3">
                            <div class="card section-height-auto height-auto">
                                <div class="card-title">
                                    IVA Paid on MOC   
                                </div>
                                <div class="card-body text-center">   
                                    <a href="javascript:void(0)" class="statistics columnAjax d-block" data-type="IVA Paid on MOC">
                                        <h1>{{ $allCasesCount['ivaPaidOnMOCCount'] ? $allCasesCount['ivaPaidOnMOCCount'] : 0 }}</h1>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-sm-12 col-md-3 col-lg-3 col-xl-3">
                            <div class="card section-height-auto height-auto">
                                <div class="card-title">
                               Failed compliance
                                </div>                     
                                <div class="card-body text-center">
                                     @php
                                        $data = faild_complince();
                                    @endphp   
                                    <a href="javascript:void(0)" class="statistics columnAjax d-block" data-type="Failed compliance">
                                        <h1 class="text-danger">{{ $data ? $data : 0  }}</h1>
                                    </a>
                                </div>
                            </div>
                        </div>
                        
                        
                    </div>
                </div>
            </div>
            <!-- // proceess -->
        </section>
    </main>
    

